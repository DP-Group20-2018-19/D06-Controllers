
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.HandyWorkerRepository;
import security.Authority;
import security.UserAccount;
import domain.Application;
import domain.Box;
import domain.Endorsement;
import domain.HandyWorker;
import domain.SocialProfile;
import domain.Tutorial;

@Service
@Transactional
public class HandyWorkerService {

	//Managed repository

	@Autowired
	private HandyWorkerRepository	handyWorkerRepository;

	//Supporting services

	@Autowired
	private ActorService			actorService;

	@Autowired
	private BoxService				boxService;


	//Simple CRUD methods

	public HandyWorker create() {
		final Authority a = new Authority();
		a.setAuthority(Authority.HANDYWORKER);

		final UserAccount account = new UserAccount();
		account.setBanned(false);
		Collection<Authority> authorities = new ArrayList<Authority>();
		authorities = account.getAuthorities();
		authorities.add(a);
		account.setAuthorities(authorities);

		final HandyWorker h = new HandyWorker();
		h.setSocialProfiles(new ArrayList<SocialProfile>());
		h.setUserAccount(account);
		h.setSuspicious(false);
		h.setApplications(new ArrayList<Application>());
		h.setEndorsements(new ArrayList<Endorsement>());
		h.setTutorials(new ArrayList<Tutorial>());
		h.setBoxes(new ArrayList<Box>());
		h.setScore(0.00);
		h.setMake("this must be a make");
		return h;
	}

	public HandyWorker findOne(final int id) {
		Assert.notNull(id);

		return this.handyWorkerRepository.findOne(id);
	}

	public Collection<HandyWorker> findAll() {
		return this.handyWorkerRepository.findAll();
	}

	public HandyWorker save(final HandyWorker h) {
		Assert.notNull(h);
		final Authority authAdmin = new Authority();
		authAdmin.setAuthority(Authority.ADMIN);

		//Assertion that the email is valid according to the checkEmail method.
		Assert.isTrue(this.actorService.checkUserEmail(h.getEmail()));

		final HandyWorker saved2;
		//Assertion that the user modifying this handyworker has the correct privilege.
		if (h.getId() != 0) {
			Assert.isTrue(this.actorService.findByPrincipal().getId() == h.getId());
			saved2 = this.handyWorkerRepository.save(h);
		} else {
			final HandyWorker saved = this.handyWorkerRepository.save(h);
			saved.setBoxes(this.boxService.generateDefaultFolders(saved));
			this.actorService.hashPassword(saved);
			saved2 = this.handyWorkerRepository.save(saved);
		}

		final String fullName = h.getName() + " " + h.getMiddleName() + " " + h.getSurname();
		h.setMake(fullName);

		return saved2;
	}
	public HandyWorker saveFromAdmin(final HandyWorker h) {
		Assert.notNull(h);
		final Authority authAdmin = new Authority();
		authAdmin.setAuthority(Authority.ADMIN);

		final HandyWorker saved2;
		//Assertion that the user modifying this handyworker has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(authAdmin));

		saved2 = this.handyWorkerRepository.save(h);

		return saved2;
	}

	public void delete(final HandyWorker h) {
		Assert.notNull(h);

		this.handyWorkerRepository.delete(h);
	}

	//Other methods

	public Collection<HandyWorker> handyWorkersInvolvedByFixUpTask(final int id) {
		return this.handyWorkerRepository.handyWorkersInvolvedByAcceptedFixUpTask(id);
	}

	public Collection<HandyWorker> endorsableHandyWorkersForCustomer(final int id) {
		return this.handyWorkerRepository.endorsableHandyWorkersForCustomer(id);
	}

	//The top handy workers in terms of complaints.
	public Collection<HandyWorker> topThreeHandyWorkersInTermsOfComplaints() {
		final ArrayList<HandyWorker> handyWorkerList = (ArrayList<HandyWorker>) this.handyWorkerRepository.topHandyWorkersInTermsOfComplaints();
		final ArrayList<HandyWorker> top3 = new ArrayList<HandyWorker>(handyWorkerList.subList(handyWorkerList.size() - 3, handyWorkerList.size()));
		return top3;
	}

	//Returns the handy worker related with a certain finder.
	public HandyWorker handyWorkerByFinder(final int id) {
		return this.handyWorkerRepository.handyWorkerByFinder(id);
	}

	//Return then handy workers with 10% more applications accepted than average.
	public Collection<HandyWorker> handyWorkerWithMoreApplicationsAcceptedThanAvg() {
		return this.handyWorkerRepository.handyWorkerWithMoreApplicationsAcceptedThanAvg();
	}

	//Returns the collection of suspicious handy workers.
	public Collection<HandyWorker> suspiciousHandyWorker() {
		return this.handyWorkerRepository.suspiciousHandyWorkers();
	}
}
