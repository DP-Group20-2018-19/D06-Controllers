
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Box;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class BoxServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private BoxService		boxService;
	@Autowired
	private ActorService	actorService;


	//Tests

	//In this instance, it's easier to check all methods in a single test, because every default box in the database cannot be modified or deleted.
	@Test
	public void testCreateListDeleteBox() {
		//Setting up the authority to execute services.
		this.authenticate("customer1");

		//Using create() to initialise a new entity.
		final Box box = this.boxService.create(this.actorService.findByPrincipal());

		box.setName("testBox");

		//Saving entity to database and confirming it exists with findAll().
		final Box saved = this.boxService.save(box);

		Collection<Box> boxes = this.boxService.findAll();
		Assert.isTrue(boxes.contains(saved));

		//Using delete() to delete the entity we created.
		this.boxService.delete(box);

		//Verifying the entity has been removed from the database.
		boxes = this.boxService.findAll();
		Assert.isTrue(!boxes.contains(box));
	}
}
