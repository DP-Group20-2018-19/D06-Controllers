
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.HandyWorker;

@Repository
public interface HandyWorkerRepository extends JpaRepository<HandyWorker, Integer> {

	//The top handy workers in terms of complaints.
	@Query("select distinct h from HandyWorker h join h.applications a join a.fixUpTask f where a.status=1 order by f.complaints.size")
	Collection<HandyWorker> topHandyWorkersInTermsOfComplaints();

	//The listing of endorsable handy workers for a certain customer.
	@Query("select distinct a.handyWorker from FixUpTask task join task.applications a where a.status=1 and task.customer.id=?1")
	Collection<HandyWorker> endorsableHandyWorkersForCustomer(int id);

	//Returns the listing of handy workers with an application accepted for a certain fix-up task.
	@Query("select distinct a.handyWorker from FixUpTask task join task.applications a where a.status=1 and task.id=?1")
	Collection<HandyWorker> handyWorkersInvolvedByAcceptedFixUpTask(int id);

	//Returns the handy worker related with a certain finder.
	@Query("select h from HandyWorker h where h.finder.id=?1")
	HandyWorker handyWorkerByFinder(int id);

	//Return then handy workers with 10% more applications accepted than average
	@Query("select hw from HandyWorker hw join hw.applications a where a.status='1' group by hw having hw.applications.size >= " + "(select avg(hw.applications.size)*1.1 from HandyWorker hw) order by hw.applications.size")
	Collection<HandyWorker> handyWorkerWithMoreApplicationsAcceptedThanAvg();

	//Returns the collection of suspicious handy workers.
	@Query("select hw from HandyWorker hw where hw.suspicious = true")
	Collection<HandyWorker> suspiciousHandyWorkers();

}
