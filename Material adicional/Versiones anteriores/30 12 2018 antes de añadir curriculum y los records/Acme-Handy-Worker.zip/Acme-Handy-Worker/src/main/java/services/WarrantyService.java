
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.WarrantyRepository;
import domain.Warranty;

@Service
@Transactional
public class WarrantyService {

	//Managed repository ---------------------------------

	@Autowired
	private WarrantyRepository	warrantyRepository;

	//Supporting services --------------------------------

	@Autowired
	private ActorService		actorService;


	// Simple CRUD methods

	public Warranty create() {
		final Warranty war = new Warranty();
		war.setFinalMode(false);
		return war;
	}

	public Warranty findOne(final int id) {
		Assert.notNull(id);

		return this.warrantyRepository.findOne(id);
	}

	public Collection<Warranty> findAll() {
		return this.warrantyRepository.findAll();
	}

	public Warranty save(final Warranty war, final boolean b) {
		Assert.notNull(war);

		//Assertion that the user modifying this sponsorship has the correct privilege.
		//Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(Authority.ADMIN));

		//A report cannot be modified outside of draft mode.
		Assert.isTrue(!war.getFinalMode());

		//Necessary to implement a way to tell the service from outside when we want to set 'isDraft' to false (orchestrated in L06).
		if (b == true)

			//We tell the system that this report is out of draft mode. It cannot be modified or deleted FROM NOW ON.
			war.setFinalMode(true);

		final Warranty saved = this.warrantyRepository.save(war);
		this.actorService.checkSpam(saved.getLaws());
		this.actorService.checkSpam(saved.getTerms());
		this.actorService.checkSpam(saved.getTitle());
		return saved;
	}

	public void delete(final Warranty war) {
		Assert.notNull(war);

		//Assertion that the user deleting this sponsorship has the correct privilege.
		//Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(Authority.ADMIN));

		this.warrantyRepository.delete(war);
	}
}
