
package controllers.referee;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ComplaintService;
import services.ReportService;
import controllers.AbstractController;
import domain.Complaint;
import domain.Report;

@Controller
@RequestMapping("report/referee")
public class ReportRefereeController extends AbstractController {

	//Services

	@Autowired
	private ReportService		reportService;

	@Autowired
	private ComplaintService	complaintService;


	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int complaintId) {
		final ModelAndView result;
		Collection<Report> reports;

		final Complaint complaint = this.complaintService.findOne(complaintId);

		reports = complaint.getReports();

		result = new ModelAndView("report/list");
		result.addObject("reports", reports);
		result.addObject("requestURI", "report/customer/list.do");

		return result;
	}
	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int complaintId) {
		final ModelAndView result;
		Report report;

		report = this.reportService.create(complaintId);
		result = this.createEditModelAndView(report);

		return result;
	}
	//
	//	//Edition
	//
	//	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	//	public ModelAndView edit(@RequestParam final int varId) {
	//		final ModelAndView result;
	//		Report report;
	//
	//		report = this.reportService.findOne(varId);
	//		Assert.notNull(report);
	//		result = this.createEditModelAndView(report);
	//
	//		return result;
	//	}
	//
	//	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	//	public ModelAndView save(@Valid final Report report, final BindingResult binding) {
	//		ModelAndView result;
	//
	//		if (binding.hasErrors())
	//			result = this.createEditModelAndView(report);
	//		else
	//			try {
	//				this.reportService.save(report, false);
	//				result = new ModelAndView("redirect:list.do");
	//			} catch (final Throwable oops) {
	//				result = this.createEditModelAndView(report, "report.commit.error");
	//			}
	//		return result;
	//	}

	//Delete (No existe en customer)

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Report report) {
		ModelAndView result;

		result = this.createEditModelAndView(report, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Report report, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("report/edit");
		result.addObject("report", report);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "report/referee/edit.do");

		return result;

	}

}
