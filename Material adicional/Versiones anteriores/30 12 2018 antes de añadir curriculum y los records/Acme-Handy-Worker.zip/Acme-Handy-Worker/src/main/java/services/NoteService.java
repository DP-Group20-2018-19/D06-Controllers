
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.NoteRepository;
import domain.Actor;
import domain.Note;
import domain.Report;

@Service
@Transactional
public class NoteService {

	//Managed repository --------------------------------

	@Autowired
	private NoteRepository		noteRepository;

	//Supporting services --------------------------------

	@Autowired
	private ActorService		actorService;

	@Autowired
	private ReportService		reportService;

	@Autowired
	private HandyWorkerService	handyWorkerService;


	//Simple CRUD methods --------------------------------

	public Note create(final int reportId) {

		//Assertion the users have the correct privilege
		final Actor principal = this.actorService.findByPrincipal();
		Assert.isTrue(this.getActorsWhoHasPrivilege(reportId).contains(principal));

		//Creating entity
		final Note n = new Note();
		n.setMoment(new Date(System.currentTimeMillis() - 1));
		n.setReport(this.reportService.findOne(reportId));

		return n;
	}

	public Collection<Note> findAll() {
		return this.noteRepository.findAll();
	}

	public Note findOne(final int id) {
		Assert.notNull(id);

		return this.noteRepository.findOne(id);
	}

	public Note save(final Note note) {
		Assert.notNull(note);

		//Assertion that the user modifying this note has the correct privilege.

		final Actor principal = this.actorService.findByPrincipal();
		Assert.isTrue(this.getActorsWhoHasPrivilege(note.getReport().getId()).contains(principal));

		//Assertion the report of the note has saved in final mode.
		Assert.isTrue(note.getReport().getFinalMode().equals(true));

		return this.noteRepository.save(note);
	}

	public void delete(final Note note) {
		Assert.notNull(note);

		//Assertion that the user deleting this note has the correct privilege.
		final Actor principal = this.actorService.findByPrincipal();
		Assert.isTrue(this.getActorsWhoHasPrivilege(note.getReport().getId()).contains(principal));

		this.noteRepository.delete(note);
	}

	private Collection<Actor> getActorsWhoHasPrivilege(final int reportId) {
		final Report report = this.reportService.findOne(reportId);
		final Collection<Actor> actors = new ArrayList<Actor>();
		actors.add(report.getReferee());
		actors.add(report.getComplaint().getCustomer());
		actors.addAll(this.handyWorkerService.handyWorkersInvolvedByFixUpTask(report.getComplaint().getFixUpTask().getId()));
		return actors;

	}

	//Other methods

	//The minimum, the maximum, the average, and the standard deviation of the number of notes per referee report.
	public Double[] minMaxAvgStddevNotesPerRefereeReport() {
		return this.noteRepository.minMaxAvgStddevNotesPerRefereeReport();
	}
}
