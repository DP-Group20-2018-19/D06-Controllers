
package controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.RefereeService;
import domain.Referee;

@Controller
@RequestMapping("referee")
public class RefereeController extends AbstractController {

	//Services

	@Autowired
	private RefereeService	refereeService;

	@Autowired
	private ActorService	actorService;


	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		final ModelAndView result;
		Referee referee;
		referee = (Referee) this.actorService.findByPrincipal();
		Assert.notNull(referee);
		result = this.createEditModelAndView(referee);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Referee referee, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(referee);
		else
			try {
				this.actorService.hashPassword(referee);
				this.refereeService.save(referee);
				result = new ModelAndView("redirect:/welcome/index.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(referee, "referee.commit.error");
			}
		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Referee referee) {
		ModelAndView result;

		result = this.createEditModelAndView(referee, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Referee referee, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("referee/edit");
		result.addObject("referee", referee);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "referee/edit.do");

		return result;

	}
}
