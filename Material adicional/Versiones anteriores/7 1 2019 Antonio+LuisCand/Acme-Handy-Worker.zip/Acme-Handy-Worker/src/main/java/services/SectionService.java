
package services;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.SectionRepository;
import domain.Section;
import domain.Tutorial;

@Service
@Transactional
public class SectionService {

	//Managed service

	@Autowired
	private SectionRepository	sectionRepository;

	//Supporting service

	@Autowired
	private ActorService		actorService;

	@Autowired
	private TutorialService		tutorialService;


	//Simple CRUD methods

	public Section create(final Integer tutorialId) {

		final Section s = new Section();
		s.setPictures(new ArrayList<String>());
		s.setNumber(1);
		s.setTutorial(this.tutorialService.findOne(tutorialId));

		return s;
	}

	public Collection<Section> findAll() {
		return this.sectionRepository.findAll();
	}

	public Section findOne(final int id) {
		Assert.notNull(id);

		return this.sectionRepository.findOne(id);
	}

	public Section save(final Section section) {
		Assert.notNull(section);

		Section saved = new Section();
		if (section.getId() != 0) {
			Assert.isTrue(this.actorService.findByPrincipal().getId() == this.sectionRepository.handyWorkerFromThisSection(section.getId()).getId());
			saved = this.sectionRepository.save(section);
		} else
			saved = this.sectionRepository.save(section);

		if (saved.getTutorial().getSections().size() == 0)
			saved.setNumber(1);
		else
			saved.setNumber(saved.getTutorial().getSections().size() + 1);

		final Tutorial tu = saved.getTutorial();
		final Collection<Section> sections = tu.getSections();
		sections.add(saved);
		tu.setSections(sections);

		this.actorService.checkSpam(saved.getText());
		this.actorService.checkSpam(saved.getTitle());
		this.tutorialService.save(tu);

		return saved;
	}

	public void delete(final Section section) {
		Assert.notNull(section);

		//Assertion that the user deleting this note has the correct privilege.
		//Assert.isTrue(this.actorService.findByPrincipal().getId() == Section.getTutorial().getHandyWorker().getId());
		Assert.isTrue(this.actorService.findByPrincipal().getId() == this.sectionRepository.handyWorkerFromThisSection(section.getId()).getId());
		final Tutorial tu = section.getTutorial();
		final Collection<Section> se = tu.getSections();
		se.remove(section);
		this.tutorialService.save(tu);
		this.sectionRepository.delete(section);
	}

	//Other methods

	//Check every picture is an URL link
	public boolean checkPictures(final int id) {
		final Collection<String> pictures = this.findOne(id).getPictures();
		boolean result = true;
		for (final String s : pictures)
			if (this.isURL(s) == false)
				result = false;
		return result;
	}

	public boolean isURL(final String url) {
		try {
			new URL(url);
			return true;
		} catch (final Exception e) {
			return false;
		}
	}

}
