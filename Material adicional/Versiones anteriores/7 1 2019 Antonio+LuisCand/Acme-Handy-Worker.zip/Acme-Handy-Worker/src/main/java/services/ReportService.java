
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ReportRepository;
import domain.Complaint;
import domain.Note;
import domain.Referee;
import domain.Report;

@Service
@Transactional
public class ReportService {

	//Managed service

	@Autowired
	private ReportRepository	reportRepository;

	//Supporting service

	@Autowired
	private ActorService		actorService;
	@Autowired
	private ComplaintService	complaintService;
	@Autowired
	private NoteService			noteService;


	//Simple CRUD methods

	public Report create(final int complaintId) {

		final Report r = new Report();

		final Referee re = (Referee) this.actorService.findByPrincipal();
		r.setReferee(re);
		final Complaint c = this.complaintService.findOne(complaintId);
		r.setComplaint(c);
		r.setNotes(new ArrayList<Note>());
		r.setFinalMode(false);
		r.setMoment(new Date(System.currentTimeMillis() - 1));

		return r;
	}

	public Collection<Report> findAll() {
		return this.reportRepository.findAll();
	}

	public Report findOne(final int id) {
		Assert.notNull(id);

		return this.reportRepository.findOne(id);
	}

	public Report save(final Report report, final boolean b) {
		Assert.notNull(report);
		Report saved;
		//Assertion that the user deleting this note has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == report.getReferee().getId());

		if (report.getId() == 0)
			report.setMoment(new Date(System.currentTimeMillis() - 1));

		//A report cannot be modified outside of draft mode.
		Assert.isTrue(!(report.getFinalMode()));

		//Necessary to implement a way to tell the service from outside when we want to set 'finalMode' to false (orchestrated in L06).
		if (b == true)
			//We tell the system that this report is in final mode. It cannot be modified or deleted FROM NOW ON.
			report.setFinalMode(true);
		if (report.getId() == 0) {
			saved = this.reportRepository.save(report);
			//Adding the report to the complaint reports' list

			final Complaint c = report.getComplaint();
			final Collection<Report> reports = c.getReports();
			reports.add(saved);
			this.complaintService.saveFromReport(c);
		} else
			saved = this.reportRepository.save(report);
		this.actorService.checkSpam(saved.getDescription());
		this.actorService.checkSpam(saved.getAttachments());

		return saved;
	}

	public void delete(final Report report) {
		Assert.notNull(report);

		//Assertion that the user deleting this note has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == report.getReferee().getId());
		//A report cannot be deleted if is in finalMode.
		Assert.isTrue(!(report.getFinalMode()));

		this.reportRepository.delete(report);
	}

	public void delete2(final Report report) {
		Assert.notNull(report);

		//Assertion that the user deleting this note has the correct privilege.

		Assert.isTrue(this.actorService.findByPrincipal().getId() == report.getReferee().getId() || this.actorService.findByPrincipal().getId() == report.getComplaint().getCustomer().getId());
		//The final mode is not present here
		//Also, we delete the notes related with the deleted report
		if (!(report.getNotes().isEmpty()))
			for (final Note n : report.getNotes())
				this.noteService.delete(n);

		this.reportRepository.delete(report);
	}

	//Other methods

	public Collection<Report> reportsFromAComplaintAndFinalModeTrue(final int complaintId) {
		return this.reportRepository.reportsFromAComplaintAndFinalModeTrue(complaintId);
	}

}
