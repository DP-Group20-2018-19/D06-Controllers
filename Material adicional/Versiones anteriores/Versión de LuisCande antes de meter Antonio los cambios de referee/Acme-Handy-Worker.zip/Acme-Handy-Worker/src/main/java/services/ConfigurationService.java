
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ConfigurationRepository;
import domain.Configuration;

@Service
@Transactional
public class ConfigurationService {

	//Managed repository

	@Autowired
	private ConfigurationRepository	configurationRepository;


	//Supporting services --------------------------------

	//	@Autowired
	//	private ActorService			actorService;

	//Simple CRUD methods

	//	public Configuration create() {
	//
	//		final Configuration c = new Configuration();
	//		c.setSystemName("Acme Handy Worker");
	//		c.setBanner("https://tinyurl.com/acme-handy-worker-logo");
	//		c.setWelcomeEN("Welcome to Acme Handy Worker!");
	//		c.setWelcomeES("�Bienvenidos a Acme Handy Worker! Precio, calidad y confianza en el mismo sitio.");
	//		ArrayList<String> spam = new ArrayList<String>();
	//		spam.add("sex"); 
	//		sex.addAll(configuration.get)
	//		c.setSpamWords(new ArrayList(Arrays.asList("sex", "viagra,cialis,one million,you've been selected,Nigeria,sexo,un mill�n,has sido seleccionado")));
	//		c.setVat(21.00);
	//		c.setCountryCode("+34");
	//		c.setCreditCardList(new ArrayList(Arrays.asList("VISA,MASTER,DINNERS,AMEX")));
	//		c.setExpireFinderMinutes(60);
	//		c.setMaxFinderResults(10);
	//		c.setPositiveWords(new ArrayList(Arrays.asList("good", "fantastic", "excellent", "amazing", "great", "terrific", "beautiful", "bueno", "fant�stico", "excelente", "incre�ble", "genial", "estupendo", "hermoso")));
	//		c.setNegativeWords(new ArrayList(Arrays.asList("not", "bad", "horrible", "average", "disaster", "no", "malo", "mediocre", "desastre")));
	//
	//		return c;
	//	}
	public Collection<Configuration> findAll() {
		return this.configurationRepository.findAll();
	}

	public Configuration findOne(final int id) {
		Assert.notNull(id);

		return this.configurationRepository.findOne(id);
	}

	public Configuration save(final Configuration configuration) {
		Assert.notNull(configuration);

		//Assertion that the user modifying this configuration has the correct privilege.
		//Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(Authority.ADMIN));

		return this.configurationRepository.save(configuration);
	}

	//	public void delete(final Configuration configuration) {
	//		Assert.notNull(configuration);
	//
	//		//Assertion that the user deleting this configuration has the correct privilege.
	//		Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(Authority.ADMIN));
	//
	//		this.configurationRepository.delete(configuration);
	//	}
}
