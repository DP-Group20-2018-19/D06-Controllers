
package services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.FixUpTaskRepository;
import domain.Application;
import domain.Complaint;
import domain.Customer;
import domain.FixUpTask;

@Service
@Transactional
public class FixUpTaskService {

	//Managed repository

	@Autowired
	private FixUpTaskRepository	fixUpTaskRepository;

	//Supporting services

	@Autowired
	private ActorService		actorService;


	//Simple CRUD methods

	public FixUpTask create() {
		final FixUpTask f = new FixUpTask();

		f.setTicker(this.generateTicker());

		final Customer c = (Customer) this.actorService.findByPrincipal();
		f.setCustomer(c);

		//		final Date now = new Date(System.currentTimeMillis() - 1);
		//		f.setPublishDate(now);
		f.setComplaints(new ArrayList<Complaint>());
		//f.setWarranty(this.warrantyService.findAll().iterator().next());
		f.setApplications(new ArrayList<Application>());

		return f;
	}

	public FixUpTask findOne(final int id) {
		Assert.notNull(id);

		return this.fixUpTaskRepository.findOne(id);
	}

	public Collection<FixUpTask> findAll() {
		return this.fixUpTaskRepository.findAll();
	}

	public FixUpTask save(final FixUpTask f) {
		Assert.notNull(f);

		//Business rule: startDate must be later than publicationDate, and earlier than endDate.
		Assert.isTrue(f.getPeriodStartDate().after(f.getPublishDate()));
		Assert.isTrue(f.getPeriodEndDate().after(f.getPeriodStartDate()));

		//Business rule: a fix-up task cannot be modified after its publication date.
		//Assert.isTrue(f.getPublishDate().after(new Date(System.currentTimeMillis())));

		//Assertion that the user modifying this trip has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == f.getCustomer().getId());

		final FixUpTask saved = this.fixUpTaskRepository.save(f);
		this.actorService.checkSpam(saved.getAddress());
		this.actorService.checkSpam(saved.getDescription());

		return saved;
	}

	public void delete(final FixUpTask f) {
		Assert.notNull(f);

		//A fix-up task cannot be deleted if it has applications.
		Assert.isTrue(f.getApplications().isEmpty());

		//Assertion that the user deleting this trip has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == f.getCustomer().getId());

		this.fixUpTaskRepository.delete(f);
	}

	//Other methods

	public FixUpTask save2(final FixUpTask f) {
		Assert.notNull(f);

		//Business rule: startDate must be later than publicationDate, and earlier than endDate.
		//		Assert.isTrue(f.getPeriodStartDate().after(f.getPublishDate()));
		//		Assert.isTrue(f.getPeriodEndDate().after(f.getPeriodStartDate()));

		//Business rule: a fix-up task cannot be modified after its publication date.
		//Assert.isTrue(f.getPublishDate().after(new Date(System.currentTimeMillis())));

		//Assertion that the user modifying this trip has the correct privilege.
		//Assert.isTrue(this.actorService.findByPrincipal().getId() == f.getCustomer().getId());

		final FixUpTask saved = this.fixUpTaskRepository.save(f);
		//		this.actorService.checkSpam(saved.getAddress());
		//		this.actorService.checkSpam(saved.getDescription());

		return saved;
	}

	//Generates the first half of the unique tickers.
	private String generateNumber() {
		final Date date = new Date();
		final DateFormat fecha = new SimpleDateFormat("yyyy/MM/dd");
		final String convertido = fecha.format(date);

		final String[] campos = convertido.split("/");
		final String year = campos[0].trim().substring(2, 4);
		final String month = campos[1].trim();
		final String day = campos[2].trim();

		final String res = year + month + day;
		return res;
	}

	//Generates the second half of the unique tickers.
	private String generateString() {
		String randomString = "";
		final int longitud = 6;
		final Random r = new Random();
		int i = 0;
		while (i < longitud) {
			final int rnd = r.nextInt(255);
			final char c = (char) (rnd);
			if ((c >= 'A' && c <= 'Z' && Character.isLetter(c) && Character.isUpperCase(c))) {
				randomString += c;
				i++;
			}
		}
		return randomString;
	}

	public Collection<FixUpTask> fixUpTaskWithApplicationnNonAccepted() {
		final Collection<FixUpTask> acceptedTasks = this.fixUpTaskWithApplicationAccepted();
		final Collection<FixUpTask> nonAcceptedTasks = new ArrayList<>();
		for (final FixUpTask f : this.findAll())
			if (!acceptedTasks.contains(f))
				nonAcceptedTasks.add(f);
		return nonAcceptedTasks;
	}

	//Generates both halves of the unique ticker and joins them with a dash.
	public String generateTicker() {
		final String res = this.generateNumber() + "-" + this.generateString();
		return res;
	}

	//The average, the minimum, the maximum, and the standard deviation of the number of fix-up tasks per user.
	public Double[] minMaxAvgStddevFixUpTasksPerUser() {
		return this.fixUpTaskRepository.minMaxAvgStddevFixUpTasksPerUser();
	}

	//The average, the minimum, the maximum, and the standard deviation of the number of applications per fix-up tasks.
	public Double[] minMaxAvgStddevApplicationsPerFixUpTask() {
		return this.fixUpTaskRepository.minMaxAvgStddevApplicationsPerFixUpTask();
	}

	//The average, the minimum, the maximum, and the standard deviation of the maximum price of the fix-up tasks.
	public Double[] minMaxAvgStddevMaximumPricePerFixUpTask() {
		return this.fixUpTaskRepository.minMaxAvgStddevMaximumPricePerFixUpTask();
	}

	//The minimum, the maximum, the average, and the standard deviation of the number of complaints per fix-up task.
	public Double[] minMaxAvgStddevComplaintsPerFixUpTask() {
		return this.fixUpTaskRepository.minMaxAvgStddevComplaintsPerFixUpTask();
	}
	//The ratio of fix-up tasks with a complaint.
	public Double ratioFixUpTaskWithComplaint() {
		return this.fixUpTaskRepository.ratioFixUpTaskWithComplaint();
	}

	//Listing of fix-up tasks for a certain warranty.
	public Collection<FixUpTask> fixUpTasksByWarranty(final int id) {
		return this.fixUpTaskRepository.fixUpTasksByWarranty(id);
	}

	//Listing of fix-up tasks with accepted applications.
	Collection<FixUpTask> fixUpTaskWithApplicationAccepted() {
		return this.fixUpTaskRepository.fixUpTaskWithApplicationAccepted();
	}
}
