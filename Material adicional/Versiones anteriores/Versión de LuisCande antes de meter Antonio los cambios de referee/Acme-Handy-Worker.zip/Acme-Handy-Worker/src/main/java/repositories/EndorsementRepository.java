
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Endorsement;

@Repository
public interface EndorsementRepository extends JpaRepository<Endorsement, Integer> {

	//Returns the received endorsements for a certain handy worker
	@Query("select e from Endorsement e where e.customerToHandy=true and e.handyWorker.id=?1")
	Collection<Endorsement> receivedEndorsementsFromHandyWorker(int actorId);

	//Returns the received endorsements for a certain customer
	@Query("select e from Endorsement e where e.customerToHandy=false and e.customer.id=?1")
	Collection<Endorsement> receivedEndorsementsFromCustomer(int actorId);

}
