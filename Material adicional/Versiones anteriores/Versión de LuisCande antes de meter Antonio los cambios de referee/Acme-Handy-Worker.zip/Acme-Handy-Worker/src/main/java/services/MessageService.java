
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.MessageRepository;
import domain.Actor;
import domain.Application;
import domain.Box;
import domain.Customer;
import domain.HandyWorker;
import domain.Message;
import domain.Priority;

@Service
@Transactional
public class MessageService {

	//Managed repository --------------------------------

	@Autowired
	private MessageRepository	messageRepository;

	//Supporting services ----------------------------

	@Autowired
	private ActorService		actorService;

	@Autowired
	private BoxService			boxService;


	//Simple CRUD methods --------------------------------

	public Message create() {

		final Message message = new Message();
		message.setPriority(Priority.NEUTRAL);

		message.setSender(this.actorService.findByPrincipal());
		final Collection<Box> boxList = new ArrayList<Box>();
		final Box box = this.boxService.getSystemBoxByName(this.actorService.findByPrincipal().getId(), "Out box");
		boxList.add(box);
		message.setBoxes(boxList);

		return message;
	}

	public Collection<Message> findAll() {

		return this.messageRepository.findAll();
	}

	public Message findOne(final int id) {
		Assert.notNull(id);

		return this.messageRepository.findOne(id);
	}

	public Message save(final Message message) {
		Assert.notNull(message);

		//Assertion that the user modifying this message has the correct privilege, that is, he or she is the sender or recipient.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == message.getSender().getId() || this.actorService.findByPrincipal().getId() == message.getRecipient().getId());

		if (this.actorService.checkSpam(message.getSubject()) || this.actorService.checkSpam(message.getBody()))
			//Sets message as spam.
			message.setSpam(true);

		return this.messageRepository.save(message);
	}

	public void delete(final Message message) {
		Assert.notNull(message);

		//Assertion that the user deleting this message has the correct privileges.
		final Box box = this.boxService.getBoxByMessageAndActor(message.getSender().getId(), message.getId());
		Assert.isTrue(this.actorService.findByPrincipal().getId() == box.getActor().getId());

		if (!box.getName().contains("Trash box")) {
			final Box b = this.boxService.getSystemBoxByName(this.actorService.findByPrincipal().getId(), "Trash box");
			this.move(message, b);

		} else
			this.messageRepository.delete(message);
	}

	//Other business methods ----------------------------

	//Creates a copy of a message and sends it to the recipient of the original message.
	//Necessary to save outside this method to avoid complications.

	//	public Message send(final Message m) {
	//		Assert.notNull(m);
	//
	//		//Parsing the message's subject and body for spam words.
	//		final boolean isSpamSubject = this.actorService.checkSpam(m.getSubject());
	//		final boolean isSpamBody = this.actorService.checkSpam(m.getBody());
	//		String boxName = "In box";
	//		if (isSpamSubject == true || isSpamBody == true)
	//			boxName = "Spam box";
	//		System.out.println(m.getRecipient());
	//		System.out.println(boxName);
	//		//Finds the system folder where the message must be sent to.
	//		final Box b = this.boxService.getSystemBoxByName(m.getRecipient().getId(), boxName);
	//
	//		final Message sentMsg = new Message();
	//
	//		sentMsg.setSubject(m.getSubject());
	//		sentMsg.setBody(m.getBody());
	//		sentMsg.setTags(m.getTags());
	//		sentMsg.setPriority(m.getPriority());
	//		sentMsg.setRecipient(m.getRecipient());
	//		sentMsg.setSender(m.getSender());
	//		sentMsg.setSent(new Date(System.currentTimeMillis() - 1));
	//		sentMsg.setBox(b);
	//
	//		return sentMsg;
	//	}

	public void send(final Message m, final Actor a) {
		Assert.notNull(m);
		Assert.notNull(a);

		//Parsing the message's subject and body for spam words.
		final boolean isSpamSubject = this.actorService.checkSpam(m.getSubject());
		final boolean isSpamBody = this.actorService.checkSpam(m.getBody());
		String boxName = "In box";
		if (isSpamSubject == true || isSpamBody == true)
			boxName = "Spam box";

		//Finds the system folder where the message must be sent to.
		final Box b = this.boxService.getSystemBoxByName(a.getId(), boxName);

		m.setRecipient(a);
		m.getBoxes().add(b);
		this.save(m);
	}
	//Moves a message from one folder to another.
	public void move(final Message message, final Box newOne) {
		Assert.notNull(message);
		Assert.notNull(newOne);

		final Box oldB = this.boxService.getBoxByMessageAndActor(this.actorService.findByPrincipal().getId(), message.getId());

		message.getBoxes().remove(oldB);
		message.getBoxes().add(newOne);

		this.save(message);
		//		final Collection<Message> newList = newOne.getMessages();
		//		newList.add(message);
		//		newOne.setMessages(newList);
		//
		//		final Box oldB = this.boxService.getBoxByMessageAndActor(message.getSender().getId(), message.getId());
		//
		//		final Collection<Message> oldList = oldB.getMessages();
		//		oldList.remove(message);
		//		oldB.setMessages(oldList);
		//		this.boxService.save(oldB);
		//
		//		final Collection<Box> boxList = message.getBoxes();
		//		boxList.remove(oldB);
		//		boxList.add(newOne);
		//		message.setBoxes(boxList);
		//
		//		this.boxService.save(newOne);
		//		this.save(message);
	}

	//Sends a message to every actors in the system.
	public void broadcastMessage(final Message m) {
		Assert.notNull(m);

		for (final Actor a : this.actorService.findAll())
			this.send(m, a);
	}

	//Sends a message to the customer and handyworker associated to an application.

	public void applicationStatusNotification(final Application a) {
		Assert.notNull(a);

		final HandyWorker hw = a.getHandyWorker();
		final Customer c = a.getFixUpTask().getCustomer();

		final Message msg = this.create();
		msg.setSubject("Application status changed / El estado de la aplicaci�n ha cambiado");
		msg.setBody("Your application status has been changed / El estado de tu aplicaci�n ha sido cambiado.");
		msg.setPriority(Priority.HIGH);
		msg.setTags("Application status / Estado de la aplicaci�n");
		msg.setSent(new Date(System.currentTimeMillis() - 1));

		this.send(msg, c);
		this.send(msg, hw);

	}

	//Other methods
	public Collection<Message> getMessagesFromBox(final int id) {
		return this.messageRepository.messagesFromBox(id);

	}
}
