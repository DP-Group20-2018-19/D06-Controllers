
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Complaint;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class ComplaintServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private ComplaintService	complaintService;


	//Test

	@Test
	public void testCreateComplaint() {
		// Setting up the authority to execute services.
		this.authenticate("customer1");

		// Using create() to initialise a new entity. Necessary Id's taken from
		// populated database.
		final Complaint complaint = this.complaintService.create(6606);//ID del FixUpTask1
		// Saving entity to database and confirming it exists with findAll().
		final Complaint saved = this.complaintService.save(complaint);

		final Complaint bbdd = this.complaintService.findOne(saved.getId());
		Assert.notNull(bbdd);
	}

	@Test
	public void testListDeleteComplaint() {
		//Setting up the authority to execute services.
		this.authenticate("customer1");

		//We retrieve a list of all complaints, and obtain the Id of one of them.
		Collection<Complaint> complaints = this.complaintService.findAll();
		final int id = complaints.iterator().next().getId();

		//Using findOne() to retrieve a particular entity and verifying it.
		final Complaint complaint = this.complaintService.findOne(id);
		Assert.notNull(complaint);

		//Using delete() to delete the entity we retrieved.
		this.complaintService.delete(complaint);

		//Verifying the entity has been removed from the database.
		complaints = this.complaintService.findAll();
		Assert.isTrue(!complaints.contains(complaint));
	}
}
