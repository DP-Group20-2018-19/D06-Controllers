
package controllers.referee;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.NoteService;
import controllers.AbstractController;
import domain.Note;

@Controller
@RequestMapping("note/referee")
public class NoteRefereeController extends AbstractController {

	//Services

	@Autowired
	private NoteService	noteService;


	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		Collection<Note> notes;

		//Listado de complaints sin referee asignado
		notes = this.noteService.findAll();

		result = new ModelAndView("note/list");
		result.addObject("notes", notes);
		result.addObject("requestURI", "note/referee/list.do");

		return result;
	}

	//Creation

	//	@RequestMapping(value = "/create", method = RequestMethod.GET)
	//	public ModelAndView create(@RequestParam final int complaintId) {
	//		final ModelAndView result;
	//		Note note;
	//
	//		note = this.noteService.create(complaintId);
	//		result = this.createEditModelAndView(report);
	//
	//		return result;
	//	}
	//
	//	//Edition
	//
	//	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	//	public ModelAndView edit(@RequestParam final int varId) {
	//		final ModelAndView result;
	//		Report report;
	//
	//		report = this.reportService.findOne(varId);
	//		Assert.notNull(report);
	//		result = this.createEditModelAndView(report);
	//
	//		return result;
	//	}
	//
	//	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	//	public ModelAndView save(@Valid final Report report, final BindingResult binding) {
	//		ModelAndView result;
	//
	//		if (binding.hasErrors())
	//			result = this.createEditModelAndView(report);
	//		else
	//			try {
	//				this.reportService.save(report, false);
	//				result = new ModelAndView("redirect:list.do");
	//			} catch (final Throwable oops) {
	//				result = this.createEditModelAndView(report, "report.commit.error");
	//			}
	//		return result;
	//	}

	//Delete (No existe en customer)

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Note note) {
		ModelAndView result;

		result = this.createEditModelAndView(note, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Note note, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("note/edit");
		result.addObject("note", note);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "note/referee/edit.do");

		return result;

	}

}
