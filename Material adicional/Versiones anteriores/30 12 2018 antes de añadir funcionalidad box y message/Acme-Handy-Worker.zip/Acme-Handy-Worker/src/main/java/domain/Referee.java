
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
public class Referee extends Actor {

	//Relationships

	private Collection<Complaint>	complaints;
	private Collection<Report>		reports;


	//Getter

	@Valid
	@NotNull
	@OneToMany(mappedBy = "referee")
	public Collection<Complaint> getComplaints() {
		return this.complaints;
	}

	@Valid
	@NotNull
	@OneToMany(mappedBy = "referee")
	public Collection<Report> getReports() {
		return this.reports;
	}

	//Setter
	public void setComplaints(final Collection<Complaint> complaints) {
		this.complaints = complaints;
	}

	public void setReports(final Collection<Report> reports) {
		this.reports = reports;
	}

}
