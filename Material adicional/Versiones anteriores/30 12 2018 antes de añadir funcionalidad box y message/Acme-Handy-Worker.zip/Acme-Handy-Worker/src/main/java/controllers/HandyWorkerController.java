
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.HandyWorkerService;
import domain.Customer;
import domain.HandyWorker;

@Controller
@RequestMapping("handyWorker")
public class HandyWorkerController extends AbstractController {

	//Services

	@Autowired
	private HandyWorkerService	handyWorkerService;

	@Autowired
	private ActorService		actorService;


	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		final ModelAndView result;
		HandyWorker handyWorker;
		handyWorker = (HandyWorker) this.actorService.findByPrincipal();
		Assert.notNull(handyWorker);
		result = this.createEditModelAndView(handyWorker);

		return result;
	}

	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		final ModelAndView result;
		HandyWorker handyWorker;

		handyWorker = this.handyWorkerService.create();
		result = this.createEditModelAndView(handyWorker);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final HandyWorker handyWorker, final BindingResult binding) {
		ModelAndView result;
		if (binding.hasErrors())
			result = this.createEditModelAndView(handyWorker);

		else
			try {
				this.handyWorkerService.save(handyWorker);
				result = new ModelAndView("redirect:/welcome/index.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(handyWorker, "handyWorker.commit.error");
			}
		return result;
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		Collection<HandyWorker> handyWorkers;

		final Customer c = (Customer) this.actorService.findByPrincipal();

		handyWorkers = this.handyWorkerService.endorsableHandyWorkersForCustomer(c.getId());

		result = new ModelAndView("handyWorker/list");
		result.addObject("handyWorkers", handyWorkers);
		result.addObject("requestURI", "handyWorker/list.do");

		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final HandyWorker handyWorker) {
		ModelAndView result;

		result = this.createEditModelAndView(handyWorker, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final HandyWorker handyWorker, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("handyWorker/edit");
		result.addObject("handyWorker", handyWorker);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "handyWorker/edit.do");

		return result;
	}
}
