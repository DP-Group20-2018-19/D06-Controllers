
package controllers.customer;

import java.util.Collection;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ComplaintService;
import controllers.AbstractController;
import domain.Complaint;
import domain.Report;

@Controller
@RequestMapping("report/customer")
public class ReportCustomerController extends AbstractController {

	//Services

	private ComplaintService	complaintService;


	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int complaintId) {
		final ModelAndView result;
		Collection<Report> reports;
		Complaint c;
		c = this.complaintService.findOne(complaintId);

		reports = c.getReports();

		result = new ModelAndView("report/list");
		result.addObject("reports", reports);
		result.addObject("requestURI", "report/customer/list.do");

		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Report report) {
		ModelAndView result;

		result = this.createEditModelAndView(report, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Report report, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("report/edit");
		result.addObject("report", report);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "report/customer/edit.do");

		return result;

	}

}
