
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.EndorsementRepository;
import security.Authority;
import domain.Actor;
import domain.Customer;
import domain.Endorsement;
import domain.HandyWorker;

@Service
@Transactional
public class EndorsementService {

	//Managed service

	@Autowired
	private EndorsementRepository	endorsementRepository;

	//Supporting service

	@Autowired
	private ActorService			actorService;

	@Autowired
	private CustomerService			customerService;

	@Autowired
	private HandyWorkerService		handyWorkerService;

	@Autowired
	private ConfigurationService	configurationService;


	//Simple CRUD methods

	public Endorsement create(final int actorId) {

		final Actor sender = this.actorService.findByPrincipal();
		final Actor receiver = this.actorService.findOne(actorId);
		final Endorsement e = new Endorsement();
		final Authority authCust = new Authority();
		final Authority authHw = new Authority();
		authCust.setAuthority(Authority.CUSTOMER);
		authHw.setAuthority(Authority.HANDYWORKER);
		e.setMoment(new Date(System.currentTimeMillis() - 1));
		if (sender.getUserAccount().getAuthorities().contains(authCust) && receiver.getUserAccount().getAuthorities().contains(authHw)) {
			e.setCustomer((Customer) sender);
			e.setCustomerToHandy(true);
			e.setHandyWorker((HandyWorker) receiver);
		} else {
			e.setCustomer((Customer) receiver);
			e.setCustomerToHandy(false);
			e.setHandyWorker((HandyWorker) sender);
		}

		return e;
	}

	public Endorsement findOne(final int id) {
		Assert.notNull(id);
		return this.endorsementRepository.findOne(id);
	}

	public Collection<Endorsement> findAll() {
		return this.endorsementRepository.findAll();
	}

	public Endorsement save(final Endorsement e) {
		Assert.notNull(e);

		if (e.getId() == 0)
			e.setMoment(new Date(System.currentTimeMillis() - 1));

		if (e.getCustomerToHandy() == true)
			Assert.isTrue(this.actorService.findByPrincipal().getId() == e.getCustomer().getId());
		if (e.getCustomerToHandy() == false)
			Assert.isTrue(this.actorService.findByPrincipal().getId() == e.getHandyWorker().getId());

		final Endorsement saved = this.endorsementRepository.save(e);
		this.actorService.checkSpam(saved.getComments());
		return saved;
	}

	public void delete(final Endorsement e) {
		Assert.notNull(e);

		if (e.getCustomerToHandy() == true)
			Assert.isTrue(this.actorService.findByPrincipal().getId() == e.getCustomer().getId());
		if (e.getCustomerToHandy() == false)
			Assert.isTrue(this.actorService.findByPrincipal().getId() == e.getHandyWorker().getId());

		this.endorsementRepository.delete(e);
	}

	//Other methods 

	public void computeScoreForAll() {
		final Collection<Customer> customers = this.customerService.getCustomersWithAtLeastOneEndorsement();
		final Collection<HandyWorker> handyWorkers = this.handyWorkerService.getHandyWorkersWithAtLeastOneEndorsement();

		//Checking that both collections aren't empty.
		Assert.isTrue(!customers.isEmpty());
		Assert.isTrue(!handyWorkers.isEmpty());

		final Collection<Actor> actors = new ArrayList<Actor>();

		actors.addAll(customers);
		actors.addAll(handyWorkers);

		for (final Actor a : actors)
			this.computeScore(a);
	}

	public Double computeScore(final Actor a) {
		Double count = 0.;
		Double score = 0.;
		Customer c = null;
		HandyWorker hw = null;
		final Authority authCust = new Authority();
		final Authority authHw = new Authority();
		final Authority authAdmin = new Authority();
		authCust.setAuthority(Authority.CUSTOMER);
		authHw.setAuthority(Authority.HANDYWORKER);
		authAdmin.setAuthority(Authority.ADMIN);

		//Assertion the user calling this method has the correct privilege
		Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(authAdmin));

		//Assertion the actor is handy worker or customer
		Assert.isTrue(a.getUserAccount().getAuthorities().contains(authHw) || a.getUserAccount().getAuthorities().contains(authCust));

		Collection<Endorsement> receivedEndorsements = new ArrayList<Endorsement>();

		if (a.getUserAccount().getAuthorities().contains(authCust)) {
			c = (Customer) a;
			receivedEndorsements = this.receivedEndorsementsFromCustomer(a.getId());

		} else if (a.getUserAccount().getAuthorities().contains(authHw)) {
			hw = (HandyWorker) a;
			receivedEndorsements = this.receivedEndorsementsFromHandyWorker(hw.getId());

		}
		if (receivedEndorsements == null || receivedEndorsements.isEmpty())
			score = 0.;
		else {
			for (final Endorsement e : receivedEndorsements) {

				final String comment = e.getComments();
				count = count + this.createScore(comment);
			}
			score = count / receivedEndorsements.size();
		}

		if (a.getUserAccount().getAuthorities().contains(authCust)) {
			c.setScore(score);
			this.customerService.saveFromAdmin(c);

		} else if (a.getUserAccount().getAuthorities().contains(authHw)) {
			hw.setScore(score);
			this.handyWorkerService.saveFromAdmin(hw);
		}

		return score;
	}
	public Double createScore(final String s) {
		int countPositive = 0;
		int countNegative = 0;
		Double score = 0.;
		final Collection<String> positiveWords = this.configurationService.findAll().iterator().next().getPositiveWords();
		final Collection<String> negativeWords = this.configurationService.findAll().iterator().next().getNegativeWords();

		for (final String x : positiveWords)
			if (s.contains(x))
				countPositive += 1;
		for (final String x : negativeWords)
			if (s.contains(x))
				countNegative += 1;

		if (countPositive == 0 && countNegative == 0) {
			score = 0.;
			return score;
		} else {
			score = (countPositive - countNegative) * 1.0 / (countPositive + countNegative) * 1.0;
			return score;
		}
	}

	//Returns the received endorsements for a certain handy worker
	public Collection<Endorsement> receivedEndorsementsFromHandyWorker(final int actorId) {
		return this.endorsementRepository.receivedEndorsementsFromHandyWorker(actorId);
	}
	//Returns the received endorsements for a certain customer
	public Collection<Endorsement> receivedEndorsementsFromCustomer(final int actorId) {
		return this.endorsementRepository.receivedEndorsementsFromCustomer(actorId);
	}
}
