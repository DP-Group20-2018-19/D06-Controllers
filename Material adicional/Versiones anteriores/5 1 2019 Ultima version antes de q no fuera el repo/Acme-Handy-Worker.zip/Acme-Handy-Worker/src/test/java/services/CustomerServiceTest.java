
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Customer;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class CustomerServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private CustomerService	customerService;


	//Tests

	@Test
	public void testCreateCustomer() {

		//Setting up the authority to execute services.

		//Using create() to initialise a new entity. Necessary Id's taken from populated database.

		final Customer customer = this.customerService.create();

		customer.setName("Luis");
		customer.setMiddleName("Lucanlun");
		customer.setSurname("Sanchez Sanchez");
		customer.setPhoto("https://www.informatica.us.es/images/logo-etsii251.png");
		customer.setEmail("luc@gmail.com");
		customer.setPhone("639854163");
		customer.setAddress("c/Tarfia");
		customer.setSuspicious(false);
		customer.getUserAccount().setUsername("JUANMA");
		customer.getUserAccount().setPassword("12345678");

		final Customer saved = this.customerService.save(customer);
		final Customer bbdd = this.customerService.findOne(saved.getId());
		Assert.notNull(bbdd);
	}
}
