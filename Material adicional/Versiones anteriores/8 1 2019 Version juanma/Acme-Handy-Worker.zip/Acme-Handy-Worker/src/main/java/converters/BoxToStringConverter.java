
package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Box;

@Component
@Transactional
public class BoxToStringConverter implements Converter<Box, String> {

	@Override
	public String convert(final Box b) {
		String result;

		if (b == null)
			result = null;
		else
			result = String.valueOf(b.getId());

		return result;
	}
}
