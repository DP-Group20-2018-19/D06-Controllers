
package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class Tutorial extends DomainEntity {

	//Attributes

	private String				title;
	private Date				moment;
	private String				summary;
	private String				pictures;

	//Relationship

	private HandyWorker			handyWorker;
	private Collection<Section>	sections;


	//Getters

	@NotBlank
	public String getTitle() {
		return this.title;
	}

	@NotNull
	@Past
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getMoment() {
		return this.moment;
	}

	@NotBlank
	public String getSummary() {
		return this.summary;
	}

	public String getPictures() {
		return this.pictures;
	}

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public HandyWorker getHandyWorker() {
		return this.handyWorker;
	}

	@Valid
	@NotNull
	@OneToMany(mappedBy = "tutorial")
	public Collection<Section> getSections() {
		return this.sections;
	}

	//Setters

	public void setTitle(final String title) {
		this.title = title;
	}

	public void setMoment(final Date moment) {
		this.moment = moment;
	}

	public void setSummary(final String summary) {
		this.summary = summary;
	}
	public void setPictures(final String pictures) {
		this.pictures = pictures;
	}

	public void setHandyWorker(final HandyWorker handyWorker) {
		this.handyWorker = handyWorker;
	}

	public void setSections(final Collection<Section> sections) {
		this.sections = sections;
	}

}
