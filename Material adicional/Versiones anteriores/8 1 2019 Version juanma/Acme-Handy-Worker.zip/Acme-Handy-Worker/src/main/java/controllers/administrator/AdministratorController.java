/*
 * AdministratorController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers.administrator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.AdministratorService;
import services.ApplicationService;
import services.ComplaintService;
import services.CustomerService;
import services.EndorsementService;
import services.FixUpTaskService;
import services.HandyWorkerService;
import services.NoteService;
import services.RefereeService;
import services.SponsorService;
import controllers.AbstractController;
import domain.Actor;
import domain.Administrator;
import domain.Customer;
import domain.HandyWorker;
import domain.Referee;
import domain.Sponsor;

@Controller
@RequestMapping("/administrator")
public class AdministratorController extends AbstractController {

	//Services

	@Autowired
	private ActorService			actorService;

	@Autowired
	private ApplicationService		applicationService;

	@Autowired
	private FixUpTaskService		fixUpTaskService;

	@Autowired
	private CustomerService			customerService;

	@Autowired
	private HandyWorkerService		handyWorkerService;

	@Autowired
	private ComplaintService		complaintService;

	@Autowired
	private NoteService				noteService;

	@Autowired
	private AdministratorService	administratorService;

	@Autowired
	private RefereeService			refereeService;

	@Autowired
	private SponsorService			sponsorService;

	@Autowired
	private EndorsementService		endorsementService;


	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		final ModelAndView result;
		Administrator administrator;

		administrator = this.administratorService.create();
		result = this.createEditModelAndView(administrator);

		return result;
	}

	//Compute score

	@RequestMapping(value = "/computeScore", method = RequestMethod.GET)
	public ModelAndView computeScore() {
		final ModelAndView result;

		this.endorsementService.computeScoreForAll();

		result = new ModelAndView("redirect:/welcome/index.do");

		return result;
	}

	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		final ModelAndView result;
		Administrator administrator;
		administrator = (Administrator) this.actorService.findByPrincipal();
		Assert.notNull(administrator);
		result = this.createEditModelAndView(administrator);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Administrator administrator, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(administrator);
		else
			try {
				this.actorService.hashPassword(administrator);
				this.actorService.save(administrator);
				result = new ModelAndView("redirect:/welcome/index.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(administrator, "actor.commit.error");
			}
		return result;
	}

	//Dashboard

	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public ModelAndView dashboard() {
		ModelAndView result;

		result = new ModelAndView("administrator/dashboard");

		result.addObject("minMaxAvgStddevFixUpTasksPerUser", Arrays.toString(this.fixUpTaskService.minMaxAvgStddevFixUpTasksPerUser()));
		result.addObject("minMaxAvgStddevApplicationsPerFixUpTask", Arrays.toString(this.applicationService.minMaxAvgStddevApplicationsPerFixUpTask()));
		result.addObject("minMaxAvgStddevMaximumPricePerFixUpTask", Arrays.toString(this.fixUpTaskService.minMaxAvgStddevMaximumPricePerFixUpTask()));
		result.addObject("minMaxAvgStddevOfferedApplications", Arrays.toString(this.applicationService.minMaxAvgStddevOfferedApplications()));
		result.addObject("ratioApplicationsPending", this.applicationService.ratioApplicationsPending());
		result.addObject("ratioApplicationsAccepted", this.applicationService.ratioApplicationsAccepted());
		result.addObject("ratioApplicationsRejected", this.applicationService.ratioApplicationsRejected());
		result.addObject("ratioPendingApplicationsThatCantBeModified", this.applicationService.ratioPendingApplicationsThatCantBeModified());
		result.addObject("listCustomersTenPerCentMore", this.customerService.listCustomersTenPerCentMore());
		result.addObject("handyWorkerWithMoreApplicationsAcceptedThanAvg", this.handyWorkerService.handyWorkerWithMoreApplicationsAcceptedThanAvg());

		result.addObject("minMaxAvgStddevComplaintsPerFixUpTask", Arrays.toString(this.complaintService.minMaxAvgStddevComplaintsPerFixUpTask()));
		result.addObject("minMaxAvgStddevNotesPerRefereeReport", Arrays.toString(this.noteService.minMaxAvgStddevNotesPerRefereeReport()));
		result.addObject("ratioFixUpTaskWithComplaint", this.fixUpTaskService.ratioFixUpTaskWithComplaint());
		result.addObject("topCustomersInTermsOfComplaints", this.customerService.topThreeCustomersInTermsOfComplaints());
		result.addObject("topHandyWorkersInTermsOfComplaints", this.handyWorkerService.topThreeHandyWorkersInTermsOfComplaints());

		result.addObject("requestURI", "administrator/dashboard.do");

		return result;
	}

	//Listing suspicious actors

	@RequestMapping(value = "/suspiciousList", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		final Collection<Actor> actors = new ArrayList<Actor>();
		final Collection<Customer> customers = this.customerService.suspiciousCustomer();
		actors.addAll(customers);
		final Collection<Administrator> admins = this.administratorService.suspiciousAdministrators();
		actors.addAll(admins);
		final Collection<HandyWorker> hws = this.handyWorkerService.suspiciousHandyWorker();
		actors.addAll(hws);
		final Collection<Referee> referees = this.refereeService.suspiciousReferees();
		actors.addAll(referees);
		final Collection<Sponsor> sponsors = this.sponsorService.suspiciousSponsors();
		actors.addAll(sponsors);

		result = new ModelAndView("administrator/suspiciousList");
		result.addObject("actors", actors);
		result.addObject("requestURI", "administrator/suspiciousList.do");

		return result;
	}
	//Ban and unban actors

	@RequestMapping(value = "/ban", method = RequestMethod.GET)
	public ModelAndView ban(@RequestParam final int varId) {
		final ModelAndView result;
		final Actor actor = this.actorService.findOne(varId);

		if (actor.isSuspicious() == true)
			this.actorService.BanOrUnban(actor.getId());

		result = new ModelAndView("redirect:/administrator/suspiciousList.do");

		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Administrator administrator) {
		ModelAndView result;

		result = this.createEditModelAndView(administrator, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Administrator administrator, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("administrator/edit");
		result.addObject("administrator", administrator);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "administrator/edit.do");

		return result;

	}
}
