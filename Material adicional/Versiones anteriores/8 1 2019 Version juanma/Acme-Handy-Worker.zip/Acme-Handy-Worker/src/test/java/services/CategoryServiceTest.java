
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Category;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class CategoryServiceTest extends AbstractTest {

	// Service under test

	@Autowired
	private CategoryService	categoryService;


	// Tests

	@Test
	public void testCreateListCategory() {
		// Setting up the authority to execute services.
		this.authenticate("admin");

		// Using create() to initialise a new entity. Necessary Id's taken from
		// populated database.
		final Category category = this.categoryService.create();
		final Category parent = this.categoryService.findOne(6471); //id Category3
		category.setParent(parent);
		category.setName("category20");//category9
		category.setNameES("categor�a20");//category9
		/*
		 * Collection<Trip> trips = new ArrayList<>();
		 * category.setTrip(trips);
		 */
		// Saving entity to database and confirming it exists with findAll().
		final Category saved = this.categoryService.save(category);

		//We retrieve a list of all notes, and check that the category is saved.
		final Collection<Category> categories = this.categoryService.findAll();
		Assert.isTrue(categories.contains(saved));

	}

	@Test
	public void testDeleteCategory() {
		// Setting up the authority to execute services.
		this.authenticate("admin");

		// Using findOne() to retrieve a particular entity and verifying it.
		final Category category = this.categoryService.findOne(6470); //ID Category2
		Assert.notNull(category);

		// Using delete() to delete the entity we retrieved.

		this.categoryService.delete(category);

		final Category bbdd = this.categoryService.findOne(category.getId());
		Assert.isNull(bbdd);
	}
}
