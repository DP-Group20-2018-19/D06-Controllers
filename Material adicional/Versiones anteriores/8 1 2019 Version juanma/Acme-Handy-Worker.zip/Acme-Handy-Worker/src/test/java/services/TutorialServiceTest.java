
package services;

import java.util.Collection;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Section;
import domain.Tutorial;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class TutorialServiceTest extends AbstractTest {

	//Service under test
	@Autowired
	private TutorialService		tutorialService;

	@Autowired
	private SectionService		sectionService;

	@Autowired
	private HandyWorkerService	handyWorkerService;

	@Autowired
	private ActorService		actorService;


	//Test
	@Test
	public void testCreateTutorial() {
		//Setting up the authority to execute services.

		this.authenticate("handyWorker1");

		//Using create() to initialise a new entity. 
		final Tutorial tutorial = this.tutorialService.create();
		tutorial.setTitle("Tutorial 1");
		tutorial.setMoment(new Date(System.currentTimeMillis() - 1));
		tutorial.setSummary("Fix a window");
		tutorial.setPictures("http:\\www.google.com");

		final Tutorial saved = this.tutorialService.save(tutorial);
		final Tutorial bbdd = this.tutorialService.findOne(saved.getId());
		Assert.notNull(bbdd);

	}

	@Test
	public void testListDeleteTutorial() {
		//Setting up the authority to execute services.
		this.authenticate("handyWorker2");

		//We retrieve a Tutorial without sections
		Collection<Tutorial> tutorials = this.handyWorkerService.findOne(this.actorService.findByPrincipal().getId()).getTutorials();
		final int id = tutorials.iterator().next().getId();

		//Using findOne() to retrieve a particular entity and verifying it.
		final Tutorial tutorial = this.tutorialService.findOne(id);
		Assert.notNull(tutorial);

		final Collection<Section> sections = tutorial.getSections();
		for (final Section s : sections)
			this.sectionService.delete(s);
		System.out.println(tutorial.getSections().isEmpty());
		this.tutorialService.save(tutorial);

		//Using delete() to delete the entity we retrieved.
		this.tutorialService.delete(tutorial);

		//Verifying the entity has been removed from the database.
		tutorials = this.tutorialService.findAll();
		Assert.isTrue(!tutorials.contains(tutorial));
	}
	@Test
	public void testCheckURL() {
		//Setting up the authority to execute services.
		this.authenticate("handyWorker1");

		final Tutorial tutorial = this.tutorialService.create();
		tutorial.setTitle("Tutorial 1");
		tutorial.setMoment(new Date(System.currentTimeMillis() - 1));
		tutorial.setSummary("Fix a window");

		final Tutorial saved = this.tutorialService.save(tutorial);
		final Tutorial bbdd = this.tutorialService.findOne(saved.getId());

		final boolean res = this.tutorialService.checkPictures(bbdd.getPictures());
		Assert.isTrue(res);
	}
}
