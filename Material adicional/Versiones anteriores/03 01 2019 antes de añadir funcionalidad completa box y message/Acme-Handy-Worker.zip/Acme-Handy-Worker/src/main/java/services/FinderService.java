
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.FinderRepository;
import security.Authority;
import domain.Actor;
import domain.Finder;
import domain.FixUpTask;
import domain.HandyWorker;

@Service
@Transactional
public class FinderService {

	//Managed service

	@Autowired
	private FinderRepository	finderRepository;

	//Supporting service

	@Autowired
	private ActorService		actorService;

	@Autowired
	private FixUpTaskService	fixUpTaskService;

	@Autowired
	private HandyWorkerService	handyWorkerService;


	//Simple CRUD methods --------------------------------

	public Finder create() {
		final Finder f = new Finder();
		f.setFixUpTasks(new ArrayList<FixUpTask>());
		return f;
	}

	public Finder findOne(final int id) {
		Assert.notNull(id);
		return this.finderRepository.findOne(id);
	}

	public Collection<Finder> findAll() {
		return this.finderRepository.findAll();
	}

	public Finder save(final Finder f) {
		Assert.notNull(f);

		//Assertion that the user modifying this finder has the correct privilege.
		Assert.isTrue(f.getId() == this.findPrincipalFinder().getId());

		//If all fields of the finder are null, the finder returns the entire listing of available trips.
		if (f.getKeyWord() == null && f.getMinPrice() == null && f.getMaxPrice() == null && f.getDateStart() == null && f.getDateEnd() == null && f.getCategory() == null && f.getWarranty() == null)
			f.setFixUpTasks(this.fixUpTaskService.findAll());

		else if (f.getCategory() != null)
			f.setFixUpTasks(f.getCategory().getFixUpTasks());
		else if (f.getWarranty() != null)
			f.setFixUpTasks(this.fixUpTaskService.fixUpTasksByWarranty(f.getWarranty().getId()));

		f.setMoment(new Date(System.currentTimeMillis() - 1));
		final Finder saved = this.finderRepository.save(f);

		return saved;
	}
	public void delete(final Finder f) {
		Assert.notNull(f);

		//Assertion that the user deleting this finder has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == this.handyWorkerService.handyWorkerByFinder(f.getId()).getId());

		this.finderRepository.delete(f);
	}
	public Finder findPrincipalFinder() {
		final Actor a = this.actorService.findByPrincipal();
		final Authority auth = new Authority();
		auth.setAuthority(Authority.HANDYWORKER);
		Assert.isTrue(a.getUserAccount().getAuthorities().contains(auth));

		final HandyWorker hw = (HandyWorker) this.actorService.findOne(a.getId());
		Finder fd = new Finder();
		if (hw.getFinder() == null) {
			fd = this.create();
			return fd;
		} else {
			final Finder saved = this.finderRepository.save(fd);
			this.handyWorkerService.save(hw);
			hw.setFinder(saved);
			return saved;
		}
	}
}
