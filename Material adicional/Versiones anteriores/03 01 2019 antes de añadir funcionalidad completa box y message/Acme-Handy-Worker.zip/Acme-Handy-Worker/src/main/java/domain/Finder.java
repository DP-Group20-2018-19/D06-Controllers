
package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class Finder extends DomainEntity {

	//Attributes

	private String					keyWord;
	private Double					minPrice;
	private Double					maxPrice;
	private Date					dateStart;
	private Date					dateEnd;
	private Date					moment;

	//Relationships

	private Collection<FixUpTask>	fixUpTasks;
	private Category				category;
	private Warranty				warranty;


	//Getters

	public String getKeyWord() {
		return this.keyWord;
	}

	@Min(value = 0)
	public Double getMinPrice() {
		return this.minPrice;
	}

	@Min(value = 0)
	public Double getMaxPrice() {
		return this.maxPrice;
	}

	@Valid
	@ManyToOne(optional = true)
	public Category getCategory() {
		return this.category;
	}

	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getDateStart() {
		return this.dateStart;
	}

	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getDateEnd() {
		return this.dateEnd;
	}

	@Past
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getMoment() {
		return this.moment;
	}

	@Valid
	@NotNull
	@ManyToMany
	public Collection<FixUpTask> getFixUpTasks() {
		return this.fixUpTasks;
	}

	@Valid
	@ManyToOne(optional = true)
	public Warranty getWarranty() {
		return this.warranty;
	}

	//Setters

	public void setKeyWord(final String keyWord) {
		this.keyWord = keyWord;
	}

	public void setMinPrice(final Double minPrice) {
		this.minPrice = minPrice;
	}

	public void setMaxPrice(final Double maxPrice) {
		this.maxPrice = maxPrice;
	}

	public void setDateStart(final Date dateStart) {
		this.dateStart = dateStart;
	}

	public void setDateEnd(final Date dateEnd) {
		this.dateEnd = dateEnd;
	}

	public void setMoment(final Date moment) {
		this.moment = moment;
	}

	public void setFixUpTasks(final Collection<FixUpTask> fixUpTasks) {
		this.fixUpTasks = fixUpTasks;
	}

	public void setCategory(final Category category) {
		this.category = category;
	}

	public void setWarranty(final Warranty warranty) {
		this.warranty = warranty;
	}

}
