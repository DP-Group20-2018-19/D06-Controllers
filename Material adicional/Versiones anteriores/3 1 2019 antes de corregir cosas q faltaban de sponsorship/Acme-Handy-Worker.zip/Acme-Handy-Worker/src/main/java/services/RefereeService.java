
package services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.RefereeRepository;
import security.Authority;
import security.UserAccount;
import domain.Box;
import domain.Complaint;
import domain.Referee;
import domain.Report;
import domain.SocialProfile;

@Service
@Transactional
public class RefereeService {

	//Managed repository

	@Autowired
	private RefereeRepository	refereeRepository;

	//Supporting services

	@Autowired
	private ActorService		actorService;

	@Autowired
	private BoxService			boxService;


	//Simple CRUD methods

	public Referee create() {
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);

		final UserAccount account = new UserAccount();
		account.setAuthorities(Arrays.asList(a));
		account.setBanned(false);

		final Referee r = new Referee();
		r.setSocialProfiles(new ArrayList<SocialProfile>());
		r.setUserAccount(account);
		r.setSuspicious(false);
		r.setBoxes(new ArrayList<Box>());

		r.setComplaints(new ArrayList<Complaint>());
		r.setReports(new ArrayList<Report>());

		return r;
	}

	public Referee findOne(final int id) {
		Assert.notNull(id);

		return this.refereeRepository.findOne(id);
	}

	public Collection<Referee> findAll() {
		return this.refereeRepository.findAll();
	}

	public Referee save(final Referee h) {
		Assert.notNull(h);

		//Assertion that the email is valid according to the checkEmail method.
		Assert.isTrue(this.actorService.checkUserEmail(h.getEmail()));

		//Assertion to make sure the address is either null or written but not blank spaces.
		Assert.isTrue(!"\\s".equals(h.getAddress()) || h.getAddress() == null);

		Referee saved2;
		//Assertion that the user modifying this Referee has the correct privilege.
		if (h.getId() != 0) {
			Assert.isTrue(this.actorService.findByPrincipal().getId() == h.getId());
			saved2 = this.refereeRepository.save(h);
		} else {
			final Authority authAdmin = new Authority();
			authAdmin.setAuthority(Authority.ADMIN);
			//Assert to check that the user creating this account has the ADMIN atuhority.
			Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(authAdmin));

			final Referee saved = this.refereeRepository.save(h);
			this.actorService.hashPassword(saved);
			saved.setBoxes(this.boxService.generateDefaultFolders(saved));
			saved2 = this.refereeRepository.save(saved);
		}

		return saved2;
	}

	public void delete(final Referee h) {
		Assert.notNull(h);

		this.refereeRepository.delete(h);
	}

	//Other methods

	//Returns the collection of suspicious referees.
	public Collection<Referee> suspiciousReferees() {
		return this.refereeRepository.suspiciousReferees();
	}
}
