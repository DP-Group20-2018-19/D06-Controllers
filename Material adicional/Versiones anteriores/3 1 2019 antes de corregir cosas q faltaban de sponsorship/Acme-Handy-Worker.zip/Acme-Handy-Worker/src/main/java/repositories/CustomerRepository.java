
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	//The listing of customers with at least one endorsement.
	@Query("select distinct c from Customer c where c.endorsements is not empty")
	Collection<Customer> getCustomersWithAtLeastOneEndorsement();

	//The top customers in terms of complaints.
	@Query("select distinct c from Customer c order by c.complaints.size desc")
	Collection<Customer> topCustomersInTermsOfComplaints();

	//The listing of customers who have published at least 10% more fix-up tasks than the average, ordered by number of applications
	@Query("select c from Customer c join c.fixUpTasks f group by c having c.fixUpTasks.size >= (select avg(c.fixUpTasks.size)*1.1 from Customer c) order by f.applications.size desc")
	Collection<Customer> listCustomersTenPerCentMore();

	//The listing of endorsable customers for a certain handy worker.
	@Query("select distinct task.customer from FixUpTask task join task.applications a where a.status=1 and a.handyWorker.id=?1")
	Collection<Customer> endorsableCustomersForHandyWorker(int id);

	//Returns the collection of suspicious customers.
	@Query("select c from Customer c where c.suspicious = true")
	Collection<Customer> suspiciousCustomers();
}
