/*
 * CustomerController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.CustomerService;
import domain.Customer;
import domain.HandyWorker;

@Controller
@RequestMapping("customer")
public class CustomerController extends AbstractController {

	//Services

	@Autowired
	private CustomerService	customerService;

	@Autowired
	private ActorService	actorService;


	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		final ModelAndView result;
		Customer customer;

		customer = (Customer) this.actorService.findByPrincipal();
		Assert.notNull(customer);
		result = this.createEditModelAndView(customer);

		return result;
	}

	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		final ModelAndView result;
		Customer customer;

		customer = this.customerService.create();
		result = this.createEditModelAndView(customer);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Customer customer, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(customer);

		else
			try {
				this.customerService.save(customer);
				result = new ModelAndView("redirect:/welcome/index.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(customer, "customer.commit.error");
			}
		return result;
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		final Collection<Customer> customers;

		final HandyWorker hw = (HandyWorker) this.actorService.findByPrincipal();

		customers = this.customerService.endorsableCustomersForHandyWorker(hw.getId());

		result = new ModelAndView("customer/list");
		result.addObject("customers", customers);
		result.addObject("requestURI", "customer/list.do");

		return result;
	}

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int customerId) {
		ModelAndView result;

		final Customer customer = this.customerService.findOne(customerId);

		result = new ModelAndView("customer/display");
		result.addObject("customer", customer);
		result.addObject("requestURI", "customer/display.do");

		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Customer customer) {
		ModelAndView result;

		result = this.createEditModelAndView(customer, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Customer customer, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("customer/edit");
		result.addObject("customer", customer);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "customer/edit.do");

		return result;
	}
}
