
package services;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.PhaseRepository;
import utilities.AbstractTest;
import domain.Application;
import domain.Phase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class PhaseServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private PhaseService		phaseService;

	@Autowired
	private ApplicationService	applicationService;

	@Autowired
	private PhaseRepository		phaseRepository;


	//Tests

	@Test
	public void testListCreatePhase() {
		//Setting up the authority to execute services.
		this.authenticate("handyWorker1");

		//Using create() to initialise a new entity. Necessary Id's taken from populated database.
		final Phase phase = this.phaseService.create();
		final Date startMoment = new GregorianCalendar(2015, Calendar.DECEMBER, 15).getTime();
		final Date endMoment = new GregorianCalendar(2017, Calendar.JANUARY, 20).getTime();

		phase.setTitle("Phase 1");
		phase.setDescription("Description");
		phase.setStartMoment(startMoment);
		phase.setEndMoment(endMoment);

		//Saving entity to database and confirming it exists with findAll().
		final Phase saved = this.phaseService.save(phase);

		final Collection<Phase> Phases = this.phaseService.findAll();
		Assert.isTrue(Phases.contains(saved));
	}

	@Test
	public void testDeletePhase() {
		//Setting up the authority to execute services.
		this.authenticate("handyWorker1");

		//We retrieve a list of all Phases, and obtain the Id of one of them.
		final Collection<Phase> phases = this.phaseService.findAll();
		final int id = phases.iterator().next().getId();

		//Using findOne() to retrieve a particular entity and verifying it.
		final Phase phase = this.phaseService.findOne(id);
		Assert.notNull(phase);

		//Getting the ID of the Application that Phase is associated to from the HandyWorker of that Application.
		final Collection<Application> Applications = phase.getHandyWorker().getApplications();

		//Using delete() to delete the entity we retrieved from the service and from the Application it belonged.
		//Deleting the Phase from its service from the list of Phases of the Application it belonged and deleting the Application in case of being the last Phase it had.
		for (final Application a : Applications)
			if (a.getPhases().contains(phase))
				if (a.getPhases().size() == 1) {
					this.phaseService.delete(phase);
					this.applicationService.delete(a);

				} else {
					this.phaseService.delete(phase);
					a.getPhases().remove(phase); // Not sure if this is needed
					this.applicationService.saveFromPhase(a);
				}
		this.phaseRepository.flush();
		//Verifying the entity has been removed from the database.
		final Phase bbdd = this.phaseService.findOne(phase.getId());
		Assert.isTrue(!phases.contains(bbdd));
	}
}
