
package services;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.FixUpTask;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class FixUpTaskServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private FixUpTaskService	fixUpTaskService;


	//Setting up the authority to execute services.
	@Test
	public void testCreateFixUpTask() {
		//Setting up the authority to execute services.
		this.authenticate("customer1");

		//Using create() to initialise a new entity.
		final FixUpTask fixUpTask = this.fixUpTaskService.create();

		final Date publishDate = new GregorianCalendar(2019, Calendar.FEBRUARY, 11).getTime();
		fixUpTask.setPublishDate(publishDate);
		fixUpTask.setDescription("Description");
		fixUpTask.setAddress("Address");
		fixUpTask.setMaxPrice(134.11);
		final Date startDate = new GregorianCalendar(2020, Calendar.FEBRUARY, 11).getTime();
		fixUpTask.setPeriodStartDate(startDate);
		final Date endDate = new GregorianCalendar(2021, Calendar.FEBRUARY, 11).getTime();
		fixUpTask.setPeriodEndDate(endDate);

		//Saving entity to database and confirming it exists with findAll().
		final FixUpTask saved = this.fixUpTaskService.save(fixUpTask);
		final FixUpTask bbdd = this.fixUpTaskService.findOne(saved.getId());
		Assert.notNull(bbdd);
	}

	@Test
	public void testListDeleteFixUpTask() {
		//Setting up the authority to execute services.
		this.authenticate("customer1");

		//Using findOne() to retrieve a particular entity and verifying it.
		final FixUpTask fixUpTask = this.fixUpTaskService.findOne(6612);
		Assert.notNull(fixUpTask);

		//Using delete() to delete the entity we retrieved.
		this.fixUpTaskService.delete(fixUpTask);

		//Verifying the entity has been removed from the database.
		final FixUpTask bbdd = this.fixUpTaskService.findOne(fixUpTask.getId());
		Assert.isNull(bbdd);
	}
}
