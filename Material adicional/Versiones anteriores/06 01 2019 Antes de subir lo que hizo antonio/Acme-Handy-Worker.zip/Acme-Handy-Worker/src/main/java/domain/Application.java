
package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class Application extends DomainEntity {

	//Attributes

	private Date				moment;
	private Status				status;
	private Double				offeredPrice;
	private String				comments;
	private String				reason;
	private CreditCard			creditCard;

	//Relationships

	private HandyWorker			handyWorker;
	private FixUpTask			fixUpTask;
	private Collection<Phase>	phases;


	//Getters

	@NotNull
	@Past
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy HH:mm")
	public Date getMoment() {
		return this.moment;
	}

	@NotNull
	@Valid
	public Status getStatus() {
		return this.status;
	}

	@NotNull
	@Min(value = 0)
	public Double getOfferedPrice() {
		return this.offeredPrice;
	}

	@NotBlank
	public String getComments() {
		return this.comments;
	}

	@NotBlank
	public String getReason() {
		return this.reason;
	}

	@Valid
	public CreditCard getCreditCard() {
		return this.creditCard;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public FixUpTask getFixUpTask() {
		return this.fixUpTask;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public HandyWorker getHandyWorker() {
		return this.handyWorker;
	}

	@Valid
	@NotNull
	@OneToMany(mappedBy = "application")
	public Collection<Phase> getPhases() {
		return this.phases;
	}

	//Setters

	public void setMoment(final Date moment) {
		this.moment = moment;
	}

	public void setStatus(final Status status) {
		this.status = status;
	}

	public void setOfferedPrice(final Double offeredPrice) {
		this.offeredPrice = offeredPrice;
	}

	public void setComments(final String comments) {
		this.comments = comments;
	}

	public void setReason(final String reason) {
		this.reason = reason;
	}

	public void setFixUpTask(final FixUpTask fixUpTask) {
		this.fixUpTask = fixUpTask;
	}

	public void setHandyWorker(final HandyWorker handyWorker) {
		this.handyWorker = handyWorker;
	}

	public void setPhases(final Collection<Phase> phases) {
		this.phases = phases;
	}

	public void setCreditCard(final CreditCard creditCard) {
		this.creditCard = creditCard;
	}
}
