
package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ApplicationRepository;
import security.Authority;
import domain.Application;
import domain.Customer;
import domain.FixUpTask;
import domain.HandyWorker;
import domain.Status;

@Service
@Transactional
public class ApplicationService {

	//Managed repository ---------------------------------

	@Autowired
	private ApplicationRepository	applicationRepository;

	//Supporting services --------------------------------

	@Autowired
	private FixUpTaskService		fixUpTaskService;

	@Autowired
	private ActorService			actorService;


	//	@Autowired
	//	private PhaseService			phaseService;

	//Simple CRUD Methods --------------------------------

	public Application create(final int taskId) {

		final Application a = new Application();

		a.setStatus(Status.PENDING);

		final FixUpTask task = this.fixUpTaskService.findOne(taskId);
		a.setFixUpTask(task);
		final HandyWorker hw = (HandyWorker) this.actorService.findByPrincipal();
		a.setHandyWorker(hw);
		a.setReason("There is no reason yet / No existe un motivo todav�a");
		a.setMoment(new Date(System.currentTimeMillis() - 1));
		return a;
	}

	public Collection<Application> findAll() {

		return this.applicationRepository.findAll();
	}

	public Application findOne(final int id) {
		Assert.notNull(id);

		return this.applicationRepository.findOne(id);
	}

	public Application save(final Application application) {
		Assert.notNull(application);

		//Once an application has been rejected, a reason must be given.
		if (application.getStatus().equals(Status.REJECTED) || application.getStatus().equals(Status.ACCEPTED))
			Assert.isTrue(!(application.getReason().isEmpty() || application.getReason() == null));

		//Once an application is accepted and has a valid credit card, all other applications for that fix-up task must be set to REJECTED.
		if (application.getStatus().equals(Status.ACCEPTED) && application.getCreditCard() != null)
			this.rejectAllOtherApplications(application.getFixUpTask());

		//Assertion that the user modifying this application has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == application.getHandyWorker().getId() || this.actorService.findByPrincipal().getId() == application.getFixUpTask().getCustomer().getId());

		//Assertion that the application has lower offered price than task�s maximun price.
		Assert.isTrue(application.getOfferedPrice() <= application.getFixUpTask().getMaxPrice());

		if (application.getMoment() == null)
			application.setMoment(new Date(System.currentTimeMillis() - 1));

		if (application.getCreditCard() != null)
			Assert.isTrue(application.getCreditCard().getBrand() == "VISA" || application.getCreditCard().getBrand() == "MASTER" || application.getCreditCard().getBrand() == "DINNERS" || application.getCreditCard().getBrand() == "AMEX");

		if (application.getStatus().equals(Status.ACCEPTED) && application.getCreditCard() != null)
			this.rejectAllOtherApplications(application.getFixUpTask());

		final Application saved = this.applicationRepository.save(application);

		return saved;
	}

	public Application saveFromPhase(final Application application) {
		Assert.notNull(application);

		//Once an application has been rejected, a reason must be given.
		if (application.getStatus().equals(Status.REJECTED) || application.getStatus().equals(Status.ACCEPTED))
			Assert.isTrue(!(application.getReason().isEmpty() || application.getReason() == null));

		//Assertion that the user modifying this application has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == application.getHandyWorker().getId() || this.actorService.findByPrincipal().getId() == application.getFixUpTask().getCustomer().getId());

		if (application.getMoment() == null)
			application.setMoment(new Date(System.currentTimeMillis() - 1));

		//		if (application.getCreditCard() != null)
		//			Assert.isTrue(application.getCreditCard().getBrand() == "VISA" || application.getCreditCard().getBrand() == "MASTER" || application.getCreditCard().getBrand() == "DINNERS" || application.getCreditCard().getBrand() == "AMEX");

		if (application.getStatus().equals(Status.ACCEPTED) && application.getCreditCard() != null)
			this.rejectAllOtherApplications(application.getFixUpTask());

		final Application saved = this.applicationRepository.save(application);

		return saved;
	}

	public void delete(final Application application) {
		Assert.notNull(application);

		//Assertion that the user deleting this application has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == application.getHandyWorker().getId());

		this.applicationRepository.delete(application);
	}

	//Other methods

	public void rejectAllOtherApplications(final FixUpTask task) {
		for (final Application ap : task.getApplications())
			if (ap.getStatus().equals(Status.ACCEPTED) && ap.getCreditCard() == null) {
				ap.setStatus(Status.REJECTED);
				ap.setReason("This fix-up task has already been assigned / Esta tarea ya ha sido asignada");
				this.saveRejectAllOtherApplications(ap);

			} else if (ap.getStatus().equals(Status.PENDING)) {
				ap.setStatus(Status.REJECTED);
				ap.setReason("This fix-up task has already been assigned / Esta tarea ya ha sido asignada");
				this.saveRejectAllOtherApplications(ap);
			}

		this.fixUpTaskService.save2(task);

	}

	public Application saveRejectAllOtherApplications(final Application a) {
		Assert.notNull(a);

		Application saved;

		//Assertion actor�s logged in is a customer
		final Authority authCust = new Authority();
		authCust.setAuthority(Authority.CUSTOMER);

		Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(authCust));

		saved = this.applicationRepository.save(a);

		return saved;
	}

	//The average, the minimum, the maximum, and the standard deviation of the number of applications per fix-up task.
	public Double[] minMaxAvgStddevApplicationsPerFixUpTask() {
		return this.applicationRepository.minMaxAvgStddevApplicationsPerFixUpTask();
	}
	//The average, the minimum, the maximum, and the standard deviation of the price offered in the applications.
	public Double[] minMaxAvgStddevOfferedApplications() {
		return this.applicationRepository.minMaxAvgStddevOfferedApplications();
	}

	//The ratio of applications with status PENDING.
	public Double ratioApplicationsPending() {
		return this.applicationRepository.ratioApplicationsPending();
	}

	//The ratio of applications with status ACCEPTED.
	public Double ratioApplicationsAccepted() {
		return this.applicationRepository.ratioApplicationsAccepted();
	}

	//The ratio of rejected applications.
	public Double ratioApplicationsRejected() {
		return this.applicationRepository.ratioApplicationsRejected();
	}

	//The ratio of pending applications that cannot change its status because their time periods elapsed.
	public Double ratioPendingApplicationsThatCantBeModified() {
		return this.applicationRepository.ratioPendingApplicationsThatCantBeModified();
	}

	//Applications which belong to fixUpTasks published by a certain customer.
	public Collection<Application> applicationsByCustomer(final Customer c) {
		return this.applicationRepository.applicationsByCustomer(c);
	}

}
