
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Section;
import domain.Tutorial;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class SectionServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private SectionService	sectionService;

	@Autowired
	private TutorialService	tutorialService;


	//Tests

	@Test
	public void testCreateSection() {
		//Setting up the authority to execute services.

		this.authenticate("handyWorker1");

		final Collection<Tutorial> tutorials = this.tutorialService.findAll();
		final int id = tutorials.iterator().next().getId();
		//Using create() to initialise a new entity. 
		final Section section = this.sectionService.create(id);
		section.setTitle("Section1");
		section.setText("text1");
		final List<String> pictures = new ArrayList<String>();
		final String s1 = "http:\\www.img.com";
		final String s2 = "http:\\www.img.com";
		pictures.add(s1);
		pictures.add(s2);
		section.setPictures(pictures);

		final Section saved = this.sectionService.save(section);
		final Section bbdd = this.sectionService.findOne(saved.getId());
		Assert.notNull(bbdd);

	}

	@Test
	public void testSaveSection() {
		//Setting up the authority to execute services.
		this.authenticate("handyWorker1");

		//We retrieve a list of all sections, and obtain the Id of one of them.
		final Collection<Section> sections = this.sectionService.findAll();
		final int id = sections.iterator().next().getId();

		//Using findOne() to retrieve a particular entity and verifying it.
		final Section section = this.sectionService.findOne(id);
		Assert.notNull(section);

		section.setText("Cambio de texto");

		this.sectionService.save(section);
	}

	@Test
	public void testListDeleteSection() {
		//Setting up the authority to execute services.
		this.authenticate("handyWorker1");

		//We retrieve a list of all sections, and obtain the Id of one of them.
		Collection<Section> sections = this.sectionService.findAll();
		final int id = sections.iterator().next().getId();

		//Using findOne() to retrieve a particular entity and verifying it.
		final Section section = this.sectionService.findOne(id);
		Assert.notNull(section);

		//Using delete() to delete the entity we retrieved.
		this.sectionService.delete(section);

		//Verifying the entity has been removed from the database.
		sections = this.sectionService.findAll();
		Assert.isTrue(!sections.contains(section));
	}
	@Test
	public void testCheckURL() {
		//Setting up the authority to execute services.
		this.authenticate("handyWorker1");

		final Collection<Tutorial> tutorials = this.tutorialService.findAll();
		final int id = tutorials.iterator().next().getId();
		//Using create() to initialise a new entity. 
		final Section section = this.sectionService.create(id);
		section.setTitle("Section1");
		section.setText("text1");
		final List<String> pictures = new ArrayList<String>();
		final String s1 = "http:\\www.img.com";
		final String s2 = "http:\\www.img.com";
		pictures.add(s1);
		pictures.add(s2);
		section.setPictures(pictures);

		final Section saved = this.sectionService.save(section);
		final Section bbdd = this.sectionService.findOne(saved.getId());

		final boolean res = this.sectionService.checkPictures(bbdd.getId());
		Assert.isTrue(res);
	}
}
