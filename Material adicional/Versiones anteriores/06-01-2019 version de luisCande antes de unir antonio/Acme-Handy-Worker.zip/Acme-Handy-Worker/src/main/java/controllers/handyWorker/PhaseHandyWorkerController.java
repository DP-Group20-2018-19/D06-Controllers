
package controllers.handyWorker;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ApplicationService;
import services.PhaseService;
import controllers.AbstractController;
import domain.Application;
import domain.Phase;

@Controller
@RequestMapping("phase/handyWorker")
public class PhaseHandyWorkerController extends AbstractController {

	//Services

	@Autowired
	private PhaseService		phaseService;

	@Autowired
	private ApplicationService	applicationService;


	//Ancillary attributes

	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int applicationId) {
		final ModelAndView result;

		final Application application = this.applicationService.findOne(applicationId);
		Assert.notNull(application);
		final Collection<Phase> phases = application.getPhases();

		result = new ModelAndView("phase/list");
		result.addObject("applicationId", applicationId);
		result.addObject("phases", phases);
		result.addObject("requestURI", "phase/handyWorker/list.do");

		return result;
	}

	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int varId) {
		final ModelAndView result;
		Phase phase;

		phase = this.phaseService.create(varId);
		result = this.createEditModelAndView(phase);

		return result;
	}

	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int varId) {
		final ModelAndView result;
		Phase phase;

		phase = this.phaseService.findOne(varId);
		Assert.notNull(phase);
		result = this.createEditModelAndView(phase);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Phase phase, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(phase);
		else
			try {
				final Phase saved = this.phaseService.save(phase);
				result = new ModelAndView("redirect:/phase/handyWorker/list.do?applicationId=" + saved.getApplication().getId());

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(phase, "phase.commit.error");
			}
		return result;
	}
	//Delete

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int phaseId) {
		ModelAndView result;
		final Phase phase = this.phaseService.findOne(phaseId);

		try {
			this.phaseService.delete(phase);
			result = new ModelAndView("redirect:/application/handyWorker/list.do");

		} catch (final Throwable oops) {
			result = this.createEditModelAndView(phase, "phase.commit.error");
		}
		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Phase phase, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(phase);
		else
			try {
				this.phaseService.delete(phase);
				result = new ModelAndView("redirect:/application/handyWorker/list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(phase, "phase.commit.error");
			}

		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Phase phase) {
		ModelAndView result;

		result = this.createEditModelAndView(phase, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Phase phase, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("phase/edit");
		result.addObject("phase", phase);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "phase/handyWorker/edit.do");

		return result;

	}
}
