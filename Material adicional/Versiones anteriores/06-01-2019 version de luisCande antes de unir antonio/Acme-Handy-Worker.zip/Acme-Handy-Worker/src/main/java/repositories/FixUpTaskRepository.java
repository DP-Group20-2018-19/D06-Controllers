
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.FixUpTask;

@Repository
public interface FixUpTaskRepository extends JpaRepository<FixUpTask, Integer> {

	//The average, the minimum, the maximum, and the standard deviation of the number of fix-up tasks per user.
	@Query("select min(c.fixUpTasks.size), max(c.fixUpTasks.size), avg(c.fixUpTasks.size), stddev(c.fixUpTasks.size) from Customer c")
	Double[] minMaxAvgStddevFixUpTasksPerUser();

	//The average, the minimum, the maximum, and the standard deviation of the number of applications per fix-up tasks.
	@Query("select min(f.applications.size), max(f.applications.size), avg(f.applications.size), stddev(f.applications.size) from FixUpTask f")
	Double[] minMaxAvgStddevApplicationsPerFixUpTask();

	//The average, the minimum, the maximum, and the standard deviation of the maximum price of the fix-up tasks.
	@Query("select min(f.maxPrice), max(f.maxPrice), avg(f.maxPrice), stddev(f.maxPrice) from FixUpTask f")
	Double[] minMaxAvgStddevMaximumPricePerFixUpTask();

	//The minimum, the maximum, the average, and the standard deviation of the number of complaints per fix-up task.
	@Query("select min(f.complaints.size), max(f.complaints.size), avg(f.complaints.size), stddev(f.complaints.size) from FixUpTask f")
	Double[] minMaxAvgStddevComplaintsPerFixUpTask();

	//The ratio of fix-up tasks with a complaint.
	@Query("select (select count(f) from FixUpTask f where f.complaints is not empty)*1.0/count(f) from FixUpTask f")
	Double ratioFixUpTaskWithComplaint();

	//Listing of fix-up tasks for a certain warranty.
	@Query("select t from FixUpTask t where t.warranty.id=?1")
	Collection<FixUpTask> fixUpTasksByWarranty(int id);

	//Listing of fix-up tasks with accepted applications.
	@Query("select f from Application a join a.fixUpTask f where a.status='1'")
	Collection<FixUpTask> fixUpTaskWithApplicationAccepted();

	//Listing of fix-up tasks with accepted applications and creditcard not null
	@Query("select f from Application a join a.fixUpTask f where (a.status='1' and a.creditCard!=null)")
	Collection<FixUpTask> fixUpTaskWithApplicationAcceptedAndCCNotNull();
}
