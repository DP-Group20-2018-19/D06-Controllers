
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.FinderRepository;
import security.Authority;
import domain.Actor;
import domain.Finder;
import domain.FixUpTask;
import domain.HandyWorker;

@Service
@Transactional
public class FinderService {

	//Managed service

	@Autowired
	private FinderRepository	finderRepository;

	//Supporting service

	@Autowired
	private ActorService		actorService;

	@Autowired
	private FixUpTaskService	fixUpTaskService;

	@Autowired
	private HandyWorkerService	handyWorkerService;


	//Simple CRUD methods --------------------------------

	public Finder create() {
		final Finder f = new Finder();
		f.setFixUpTasks(new ArrayList<FixUpTask>());
		return f;
	}

	public Finder findOne(final int id) {
		Assert.notNull(id);
		return this.finderRepository.findOne(id);
	}

	public Collection<Finder> findAll() {
		return this.finderRepository.findAll();
	}

	public Finder save(final Finder f) {
		Assert.notNull(f);
		//Assertion that the user modifying this finder has the correct privilege.
		Assert.isTrue(f.getId() == this.findPrincipalFinder().getId());//this.findPrincipalFinder().getId()
		//If all fields of the finder are null, the finder returns the entire listing of available trips.
		f.setMoment(new Date(System.currentTimeMillis() - 1));
		final Finder saved = this.finderRepository.save(f);
		return saved;
	}

	public void delete(final Finder f) {
		Assert.notNull(f);

		//Assertion that the user deleting this finder has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == this.handyWorkerService.handyWorkerByFinder(f.getId()).getId());

		this.finderRepository.delete(f);
	}

	public Finder findPrincipalFinder() {
		final Actor a = this.actorService.findByPrincipal();
		final Authority auth = new Authority();
		auth.setAuthority(Authority.HANDYWORKER);
		Assert.isTrue(a.getUserAccount().getAuthorities().contains(auth));

		final HandyWorker hw = (HandyWorker) this.actorService.findOne(a.getId());
		Finder fd = new Finder();
		if (hw.getFinder() == null) {
			fd = this.create();
			final Finder saved = this.finderRepository.save(fd);
			hw.setFinder(saved);
			this.handyWorkerService.save(hw);
			return saved;
		} else
			//			fd = hw.getFinder();
			//			final Finder saved = this.save(fd);
			//			this.handyWorkerService.save(hw);
			//			hw.setFinder(saved);
			return hw.getFinder();
	}

	public Collection<FixUpTask> find(final Finder finder) {
		Assert.notNull(finder);
		String keyWord = finder.getKeyWord();
		Double minPrice = finder.getMinPrice(), maxPrice = finder.getMaxPrice();
		Date dateStart = finder.getDateStart(), dateEnd = finder.getDateEnd();

		if (finder.getKeyWord() == null)
			keyWord = "";
		if (finder.getMinPrice() == null)
			minPrice = 0.0;
		if (finder.getMaxPrice() == null)
			maxPrice = 9999999.9;
		if (finder.getDateStart() == null)
			dateStart = new Date(631152000L);
		if (finder.getDateEnd() == null)
			dateEnd = new Date(2524694400000L);

		final Collection<FixUpTask> firstResults = this.findFixUpTasks(keyWord, minPrice, maxPrice, dateStart, dateEnd);
		Collection<FixUpTask> secondResults = new ArrayList<>();
		Collection<FixUpTask> thirdResults = new ArrayList<>();

		if (finder.getCategory() != null)
			secondResults = finder.getCategory().getFixUpTasks();
		else
			secondResults = this.fixUpTaskService.findAll();

		if (finder.getWarranty() != null)
			thirdResults = this.fixUpTaskService.fixUpTasksByWarranty(finder.getWarranty().getId());
		else
			thirdResults = this.fixUpTaskService.findAll();

		return this.intersection(this.intersection(firstResults, secondResults), thirdResults);
	}

	private Collection<FixUpTask> intersection(final Collection<FixUpTask> a, final Collection<FixUpTask> b) {
		final Collection<FixUpTask> c = new ArrayList<>();
		final Collection<FixUpTask> mayor = a.size() > b.size() ? a : b;
		for (final FixUpTask f : mayor)
			if (a.contains(f) && b.contains(f))
				c.add(f);
		return c;
	}

	//Search fixUpTask 
	public Collection<FixUpTask> findFixUpTasks(final String keyWord, final Double minPrice, final Double maxPrice, final Date dateStart, final Date dateEnd) {
		return this.finderRepository.findFixUpTasks(keyWord, minPrice, maxPrice, dateStart, dateEnd);
	}
}
