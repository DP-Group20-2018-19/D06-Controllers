
package controllers.handyWorker;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ComplaintService;
import services.FixUpTaskService;
import controllers.AbstractController;
import domain.Complaint;
import domain.FixUpTask;

@Controller
@RequestMapping("complaint/handyWorker")
public class ComplaintHandyWorkerController extends AbstractController {

	//Services

	@Autowired
	private ComplaintService	complaintService;

	@Autowired
	private FixUpTaskService	fixUpTaskService;


	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		final Collection<Complaint> complaints = new ArrayList<Complaint>();

		for (final FixUpTask f : this.fixUpTaskService.fixUpTaskWithApplicationAcceptedAndCCNotNull())
			complaints.addAll(f.getComplaints());
		result = new ModelAndView("complaint/list");
		result.addObject("complaints", complaints);
		result.addObject("requestURI", "complaint/handyWorker/list.do");

		return result;
	}
	@RequestMapping(value = "/listByFixUpTask", method = RequestMethod.GET)
	public ModelAndView listByFixUpTask(@RequestParam final int fixUpTaskId) {
		final ModelAndView result;
		Collection<Complaint> complaints;

		final FixUpTask fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);
		complaints = fixUpTask.getComplaints();

		result = new ModelAndView("complaint/list");
		result.addObject("complaints", complaints);
		result.addObject("requestURI", "complaint/handyWorker/listByFixUpTask.do");

		return result;
	}

	//Display

	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int complaintId) {
		ModelAndView result;
		Complaint complaint;

		complaint = this.complaintService.findOne(complaintId);
		result = new ModelAndView("complaint/display");
		result.addObject("complaint", complaint);
		result.addObject("requestURI", "complaint/display.do");

		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Complaint complaint) {
		ModelAndView result;

		result = this.createEditModelAndView(complaint, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Complaint complaint, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("complaint/edit");
		result.addObject("complaint", complaint);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "complaint/handyWorker/edit.do");

		return result;

	}

}
