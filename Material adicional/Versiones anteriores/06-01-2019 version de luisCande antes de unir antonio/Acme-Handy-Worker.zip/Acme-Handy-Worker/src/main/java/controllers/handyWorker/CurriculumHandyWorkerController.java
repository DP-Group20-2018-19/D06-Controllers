
package controllers.handyWorker;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.CurriculumService;
import controllers.AbstractController;
import domain.Curriculum;
import domain.HandyWorker;

@Controller
@RequestMapping("curriculum/handyWorker")
public class CurriculumHandyWorkerController extends AbstractController {

	//Services

	@Autowired
	private ActorService		actorService;

	@Autowired
	private CurriculumService	curriculumService;


	//Options
	@RequestMapping(value = "/createOrDisplay", method = RequestMethod.GET)
	public ModelAndView createOrDisplay() {

		final HandyWorker hw = ((HandyWorker) this.actorService.findByPrincipal());
		if (hw.getCurriculum() == null)
			return this.create();
		else
			return this.display();
	}
	//Create 
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		final ModelAndView result;
		Curriculum curriculum;

		curriculum = this.curriculumService.create();
		result = this.createEditModelAndView(curriculum);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Curriculum curriculum, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(curriculum);
		else
			try {
				this.curriculumService.save(curriculum);
				result = new ModelAndView("redirect:/curriculum/handyWorker/display.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(curriculum, "curriculum.commit.error");
			}
		return result;
	}

	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display() {
		final ModelAndView result;

		final HandyWorker hw = ((HandyWorker) this.actorService.findByPrincipal());
		final Curriculum curriculum = hw.getCurriculum();
		Assert.notNull(curriculum);

		result = new ModelAndView("curriculum/display");
		result.addObject("curriculum", curriculum);
		result.addObject("requestURI", "curriculum/handyWorker/display.do");

		return result;
	}

	//Delete 
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int curriculumId) {
		ModelAndView result;
		Curriculum curriculum;

		curriculum = this.curriculumService.findOne(curriculumId);
		Assert.notNull(curriculum);

		try {
			this.curriculumService.delete(curriculum);
			result = new ModelAndView("redirect:/welcome/index.do");

		} catch (final Throwable oops) {
			result = this.displayError(curriculum, "curriculum.delete.error");
		}

		return result;
	}

	protected ModelAndView displayError(final Curriculum curriculum, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("curriculum/display");
		result.addObject("curriculum", curriculum);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "curriculum/handyWorker/display.do");

		return result;

	}

	protected ModelAndView createEditModelAndView(final Curriculum curriculum) {
		ModelAndView result;

		result = this.createEditModelAndView(curriculum, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Curriculum curriculum, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("curriculum/edit");
		result.addObject("curriculum", curriculum);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "curriculum/handyWorker/edit.do");

		return result;

	}

}
