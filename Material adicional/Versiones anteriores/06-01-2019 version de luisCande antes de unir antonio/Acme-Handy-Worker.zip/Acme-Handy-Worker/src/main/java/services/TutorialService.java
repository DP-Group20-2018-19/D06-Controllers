
package services;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.TutorialRepository;
import domain.HandyWorker;
import domain.Section;
import domain.Sponsorship;
import domain.Tutorial;

@Service
@Transactional
public class TutorialService {

	//Managed repository ---------------------------------

	@Autowired
	private TutorialRepository	tutorialRepository;

	//Supporting services --------------------------------

	@Autowired
	private ActorService		actorService;

	@Autowired
	private SponsorshipService	sponsorshipService;


	// Simple CRUD methods

	public Tutorial create() {
		final Tutorial tu = new Tutorial();
		final HandyWorker w = (HandyWorker) this.actorService.findByPrincipal();
		tu.setHandyWorker(w);
		tu.setSections(new ArrayList<Section>());

		return tu;
	}

	public Tutorial findOne(final int id) {
		Assert.notNull(id);

		return this.tutorialRepository.findOne(id);
	}

	public Collection<Tutorial> findAll() {
		return this.tutorialRepository.findAll();
	}

	public Tutorial save(final Tutorial tu) {
		Assert.notNull(tu);

		//Assertion that the user modifying this tutorial has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == tu.getHandyWorker().getId());

		final Tutorial saved = this.tutorialRepository.save(tu);
		this.actorService.checkSpam(saved.getSummary());
		this.actorService.checkSpam(saved.getTitle());
		return saved;
	}

	public void delete(final Tutorial tu) {
		Assert.notNull(tu);

		//Assertion that the user deleting this sponsorship has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == tu.getHandyWorker().getId());

		this.tutorialRepository.delete(tu);
	}

	//Other methods

	//Selects an sponsorship at random, if any.
	public Sponsorship selectRandomSponsorship() {
		final Collection<Sponsorship> sponsorships = this.sponsorshipService.findAll();
		if (sponsorships.isEmpty())
			return null;
		else {
			final Random rnd = new Random();
			final int i = rnd.nextInt(sponsorships.size());
			return (Sponsorship) sponsorships.toArray()[i];
		}
	}

	//Check every picture is an URL link
	public boolean checkPictures(final int id) {
		final Collection<String> pictures = this.findOne(id).getPictures();
		boolean result = true;
		for (final String s : pictures)
			if (this.isURL(s) == false)
				result = false;
		return result;
	}

	public boolean isURL(final String url) {
		try {
			new URL(url);
			return true;
		} catch (final Exception e) {
			return false;
		}
	}

	//Other methods

	//Retrieves the tutorial of a certain section.
	public Tutorial tutorialBySection(final int sectionId) {
		return this.tutorialRepository.tutorialBySection(sectionId);
	}
}
