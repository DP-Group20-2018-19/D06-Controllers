
package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.HandyWorkerService;
import services.TutorialService;
import domain.HandyWorker;
import domain.Sponsorship;
import domain.Tutorial;

@Controller
@RequestMapping("tutorial")
public class TutorialController extends AbstractController {

	//Services

	@Autowired
	private TutorialService		tutorialService;

	@Autowired
	private HandyWorkerService	handyWorkerService;


	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int tutorialId) {
		ModelAndView result;
		Tutorial tutorial;
		final Sponsorship sponsorship;
		tutorial = this.tutorialService.findOne(tutorialId);
		sponsorship = this.tutorialService.selectRandomSponsorship(tutorialId);

		result = new ModelAndView("tutorial/display");
		result.addObject("tutorial", tutorial);
		result.addObject("sponsorship", sponsorship);
		result.addObject("requestURI", "tutorial/display.do");

		return result;
	}

	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		Collection<Tutorial> tutorials;

		tutorials = this.tutorialService.findAll();

		result = new ModelAndView("tutorial/list");
		result.addObject("tutorials", tutorials);
		result.addObject("requestURI", "tutorial/list.do");

		return result;
	}

	@RequestMapping(value = "/listH", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int handyWorkerId) {
		final ModelAndView result;
		Collection<Tutorial> tutorials;

		final HandyWorker handyWorker = this.handyWorkerService.findOne(handyWorkerId);
		tutorials = handyWorker.getTutorials();

		result = new ModelAndView("tutorial/list");
		result.addObject("tutorials", tutorials);
		result.addObject("requestURI", "tutorial/listH.do");

		return result;
	}
}
