
package controllers.handyWorker;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ApplicationService;
import services.PhaseService;
import controllers.AbstractController;
import domain.Application;
import domain.Phase;

@Controller
@RequestMapping("phase/handyWorker")
public class PhaseHandyWorkerController extends AbstractController {

	//Services

	@Autowired
	private PhaseService		phaseService;

	@Autowired
	private ApplicationService	applicationService;

	//Ancillary attributes

	private int					applicationId;


	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int varId) {
		final ModelAndView result;

		Assert.notNull(varId);
		this.setApplicationId(varId);
		final Application application = this.applicationService.findOne(varId);
		Assert.notNull(application);
		final Collection<Phase> phases = application.getPhases();

		result = new ModelAndView("phase/list");
		result.addObject("varId", varId);
		result.addObject("phases", phases);
		result.addObject("requestURI", "phase/handyWorker/list.do");

		return result;
	}

	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		final ModelAndView result;
		Phase phase;

		phase = this.phaseService.create();
		result = this.createEditModelAndView(phase);

		return result;
	}

	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int varId) {
		final ModelAndView result;
		Phase phase;

		phase = this.phaseService.findOne(varId);
		Assert.notNull(phase);
		result = this.createEditModelAndView(phase);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Phase phase, final BindingResult binding) {
		ModelAndView result;
		final int applicationId = this.getApplicationId();

		if (binding.hasErrors())
			result = this.createEditModelAndView(phase);
		else
			try {
				final Phase saved = this.phaseService.save(phase);

				final Application a = this.applicationService.findOne(applicationId);
				final Collection<Phase> phases = a.getPhases();
				if (!phases.contains(saved)) {
					phases.add(saved);
					a.setPhases(phases);
					this.applicationService.save(a);
					result = this.list(applicationId);
				} else {
					this.applicationService.save(a);
					result = this.list(applicationId);
				}
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(phase, "phase.commit.error");
			}
		return result;
	}
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Phase phase, final BindingResult binding) {
		ModelAndView result;
		final int fixUpTaskId = this.getApplicationId();

		if (binding.hasErrors())
			result = this.createEditModelAndView(phase, binding.toString());
		else
			try {
				this.phaseService.delete(phase);
				result = this.list(fixUpTaskId);
			} catch (final Throwable oops) {
				//result = this.createEditModelAndView(phase, "phase.commit.error");
				result = this.createEditModelAndView(phase, oops.getMessage());
			}

		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Phase phase) {
		ModelAndView result;

		result = this.createEditModelAndView(phase, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Phase phase, final String messageCode) {
		ModelAndView result;
		final int applicationId = this.getApplicationId();

		result = new ModelAndView("phase/edit");
		result.addObject("phase", phase);
		result.addObject("applicationId", applicationId);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "phase/handyWorker/edit.do");

		return result;

	}

	public int getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(final int applicationId) {
		this.applicationId = applicationId;
	}
}
