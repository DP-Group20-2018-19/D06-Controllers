
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Application;
import domain.Customer;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Integer> {

	//The average, the minimum, the maximum, and the standard deviation of the number of applications per fix-up task.
	@Query("select min(f.applications.size), max(f.applications.size), avg(f.applications.size), stddev(f.applications.size) from FixUpTask f")
	Double[] minMaxAvgStddevApplicationsPerFixUpTask();

	//The average, the minimum, the maximum, and the standard deviation of the price offered in the applications.
	@Query("select min(a.offeredPrice), max(a.offeredPrice), avg(a.offeredPrice), stddev(a.offeredPrice) from Application a")
	Double[] minMaxAvgStddevOfferedApplications();

	//The ratio of pending applications.
	@Query("select (select count(a) from Application a where a.status=0)*1.0/count(a) from Application a")
	Double ratioApplicationsPending();

	//The ratio of accepted applications.
	@Query("select (select count(a) from Application a where a.status=1)*1.0/count(a) from Application a")
	Double ratioApplicationsAccepted();

	//The ratio of rejected applications.
	@Query("select (select count(a) from Application a where a.status=2)*1.0/count(a) from Application a")
	Double ratioApplicationsRejected();

	//The ratio of pending applications that cannot change its status because their time periods elapsed.
	@Query("select (select count(a) from Application a where a.status=0 AND a.moment>a.fixUpTask.periodStartDate)*1.0/count(a) from Application a")
	Double ratioPendingApplicationsThatCantBeModified();

	//Applications which belong to fixup tasks published by a certain customer.
	@Query("select a from Application a where a.fixUpTask.customer = ?1")
	Collection<Application> applicationsByCustomer(Customer c);

}
