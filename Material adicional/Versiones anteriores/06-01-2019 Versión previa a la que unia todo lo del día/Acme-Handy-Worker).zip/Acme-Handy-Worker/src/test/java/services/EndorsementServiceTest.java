
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Customer;
import domain.Endorsement;
import domain.HandyWorker;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class EndorsementServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private EndorsementService	endorsementService;

	@Autowired
	private ActorService		actorService;

	@Autowired
	private HandyWorkerService	handyWorkerService;


	//Tests

	@Test
	public void testCreateEndorsement() {

		//Setting up the authority to execute services.

		this.authenticate("customer2");

		//Using create() to initialise a new entity. Necessary Id's taken from populated database.
		final Collection<HandyWorker> hws = this.handyWorkerService.findAll();
		final int id = hws.iterator().next().getId();

		final Endorsement endorsement = this.endorsementService.create(id); //id de HandyWorker random

		endorsement.setComments("I`m sending this message to handy worker 3");

		//Saving entity to database and confirming it exists with findAll().
		final Endorsement saved = this.endorsementService.save(endorsement);

		final Collection<Endorsement> endorsements = this.endorsementService.findAll();
		Assert.isTrue(endorsements.contains(saved));
	}

	@Test
	public void testListDeleteEndorsement() {

		//Setting up the authority to execute services.
		this.authenticate("customer1");
		Customer c = new Customer();
		c = (Customer) this.actorService.findByPrincipal();
		//We retrieve a list of all contacts, and obtain the Id of one of them.
		final Collection<Endorsement> endorsements = c.getEndorsements();
		final int id = endorsements.iterator().next().getId();

		//Using findOne() to retrieve a particular entity and verifying it.
		final Endorsement endorsement = this.endorsementService.findOne(id);
		Assert.notNull(endorsement);

		//Using delete() to delete the entity we retrieved.
		this.endorsementService.delete(endorsement);

		//Verifying the entity has been removed from the database.
		final Endorsement bbdd = this.endorsementService.findOne(endorsement.getId());
		Assert.isTrue(!endorsements.contains(bbdd));
	}
}
