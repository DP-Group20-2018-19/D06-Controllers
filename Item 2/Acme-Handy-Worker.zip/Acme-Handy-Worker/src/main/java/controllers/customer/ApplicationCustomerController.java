
package controllers.customer;

import java.util.Calendar;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ApplicationService;
import services.ConfigurationService;
import services.FixUpTaskService;
import domain.Application;
import domain.FixUpTask;

@Controller
@RequestMapping("application/customer")
public class ApplicationCustomerController {

	@Autowired
	private FixUpTaskService		fixUpTaskService;
	@Autowired
	private ApplicationService		applicationService;
	@Autowired
	private ConfigurationService	configurationService;


	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int fixUpTaskId) {
		final ModelAndView result;
		Collection<Application> applications;

		final FixUpTask fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);
		applications = fixUpTask.getApplications();

		result = new ModelAndView("application/list");
		result.addObject("applications", applications);
		result.addObject("requestURI", "application/customer/list.do");

		return result;
	}

	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int applicationId) {
		final ModelAndView result;
		final Application application = this.applicationService.findOne(applicationId);
		Assert.notNull(application);
		result = this.createEditModelAndView(application);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Application application, final BindingResult binding) {
		ModelAndView result;
		Application saved;

		final int year = Calendar.getInstance().get(Calendar.YEAR);
		final int month = Calendar.getInstance().get(Calendar.MONTH);

		if (binding.hasErrors())
			result = this.createEditModelAndView(application);
		else if (application.getCreditCard().getExpYear() < year)
			result = this.createEditModelAndView(application, "application.creditCard.error");
		else if (application.getCreditCard().getExpYear() == year && application.getCreditCard().getExpMonth() < month + 1)
			result = this.createEditModelAndView(application, "application.creditCard.error");
		else
			try {
				saved = this.applicationService.save(application);
				result = new ModelAndView("redirect:/application/customer/list.do?fixUpTaskId=" + saved.getFixUpTask().getId());
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(application, "application.commit.error");
			}
		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Application application) {
		ModelAndView result;

		result = this.createEditModelAndView(application, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Application application, final String messageCode) {
		ModelAndView result;
		final Collection<String> brands = this.configurationService.findAll().iterator().next().getCreditCardList();
		result = new ModelAndView("application/edit");
		result.addObject("application", application);
		result.addObject("brands", brands);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "application/customer/edit.do");

		return result;

	}

}
