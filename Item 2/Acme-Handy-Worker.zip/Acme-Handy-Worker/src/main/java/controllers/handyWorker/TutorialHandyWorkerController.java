
package controllers.handyWorker;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.HandyWorkerService;
import services.TutorialService;
import controllers.AbstractController;
import domain.HandyWorker;
import domain.Sponsorship;
import domain.Tutorial;

@Controller
@RequestMapping("tutorial/handyWorker")
public class TutorialHandyWorkerController extends AbstractController {

	//Services

	@Autowired
	private TutorialService		tutorialService;

	@Autowired
	private ActorService		actorService;

	@Autowired
	private HandyWorkerService	handyWorkerService;


	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int tutorialId) {
		ModelAndView result;
		Tutorial tutorial;
		final Sponsorship sponsorship;
		tutorial = this.tutorialService.findOne(tutorialId);
		sponsorship = this.tutorialService.selectRandomSponsorship();

		result = new ModelAndView("tutorial/display");
		result.addObject("tutorial", tutorial);
		result.addObject("sponsorship", sponsorship);
		result.addObject("requestURI", "tutorial/display.do");

		return result;
	}

	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int tutorialId) {
		ModelAndView result;
		Tutorial tutorial;

		tutorial = this.tutorialService.findOne(tutorialId);
		Assert.notNull(tutorial);
		result = this.createEditModelAndView(tutorial);

		return result;
	}

	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		final ModelAndView result;
		Tutorial tutorial;

		tutorial = this.tutorialService.create();
		result = this.createEditModelAndView(tutorial);

		return result;
	}

	//Listing

	@RequestMapping(value = "/listHandy", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		Collection<Tutorial> tutorials;

		final HandyWorker handyWorker = this.handyWorkerService.findOne(this.actorService.findByPrincipal().getId());
		tutorials = handyWorker.getTutorials();

		result = new ModelAndView("tutorial/listHandy");
		result.addObject("tutorials", tutorials);
		result.addObject("requestURI", "tutorial/handyWorker/listHandy.do");

		return result;
	}

	//Delete

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Tutorial tutorial, final BindingResult binding) {
		ModelAndView result;

		try {
			this.tutorialService.delete(tutorial);
			result = new ModelAndView("redirect:/tutorial/handyWorker/listHandy.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(tutorial, "tutorial.commit.error");
		}
		return result;
	}

	//Save

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Tutorial tutorial, final BindingResult binding) {
		ModelAndView result;
		if (binding.hasErrors())
			result = this.createEditModelAndView(tutorial);
		else
			try {
				this.tutorialService.save(tutorial);
				result = new ModelAndView("redirect:/tutorial/handyWorker/listHandy.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(tutorial, "tutorial.commit.error");
			}
		return result;
	}
	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Tutorial tutorial) {
		ModelAndView result;

		result = this.createEditModelAndView(tutorial, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Tutorial tutorial, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("tutorial/edit");
		result.addObject("tutorial", tutorial);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "tutorial/handyWorker/edit.do");

		return result;

	}
}
