
package services;

import java.net.URL;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.SectionRepository;
import domain.Section;

@Service
@Transactional
public class SectionService {

	//Managed service

	@Autowired
	private SectionRepository	sectionRepository;

	//Supporting service

	@Autowired
	private ActorService		actorService;

	@Autowired
	private TutorialService		tutorialService;


	//Simple CRUD methods

	public Section create() {

		final Section s = new Section();

		return s;
	}

	public Collection<Section> findAll() {
		return this.sectionRepository.findAll();
	}

	public Section findOne(final int id) {
		Assert.notNull(id);

		return this.sectionRepository.findOne(id);
	}

	public Section save(final Section section) {
		Assert.notNull(section);

		//Assertion that the user deleting this note has the correct privilege.
		Section saved = new Section();
		if (section.getId() != 0) {
			Assert.isTrue(this.actorService.findByPrincipal().getId() == this.sectionRepository.handyWorkerFromThisSection(section.getId()).getId());
			saved = this.sectionRepository.save(section);
		} else
			saved = this.sectionRepository.save(section);

		if (section.getNumber() == null)
			section.setNumber(1);
		else
			section.setNumber(this.tutorialService.tutorialBySection(section.getId()).getSections().size() + 1);
		this.actorService.checkSpam(saved.getText());
		this.actorService.checkSpam(saved.getTitle());
		return saved;
	}
	public void delete(final Section section) {
		Assert.notNull(section);

		//Assertion that the user deleting this note has the correct privilege.
		//Assert.isTrue(this.actorService.findByPrincipal().getId() == Section.getTutorial().getHandyWorker().getId());
		Assert.isTrue(this.actorService.findByPrincipal().getId() == this.sectionRepository.handyWorkerFromThisSection(section.getId()).getId());
		this.sectionRepository.delete(section);
	}
	//Other methods

	//Check every picture is an URL link
	public boolean checkPictures(final int id) {
		final Collection<String> pictures = this.findOne(id).getPictures();
		boolean result = true;
		for (final String s : pictures)
			if (this.isURL(s) == false)
				result = false;
		return result;
	}

	public boolean isURL(final String url) {
		try {
			new URL(url);
			return true;
		} catch (final Exception e) {
			return false;
		}
	}

}
