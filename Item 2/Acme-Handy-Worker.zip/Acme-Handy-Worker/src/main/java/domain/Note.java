
package domain;

import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class Note extends DomainEntity {

	//Attributes

	private Date	moment;
	private String	mandatoryComment;
	private String	customerComment;
	private String	refereeComment;
	private String	handyWorkerComment;

	//Relationships

	private Report	report;


	//Getters

	@NotNull
	@Past
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy HH:mm")
	public Date getMoment() {
		return this.moment;
	}

	@NotBlank
	public String getMandatoryComment() {
		return this.mandatoryComment;
	}

	public String getCustomerComment() {
		return this.customerComment;
	}

	public String getRefereeComment() {
		return this.refereeComment;
	}
	public String getHandyWorkerComment() {
		return this.handyWorkerComment;
	}

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Report getReport() {
		return this.report;
	}

	//Setters

	public void setMoment(final Date moment) {
		this.moment = moment;
	}

	public void setMandatoryComment(final String mandatoryComment) {
		this.mandatoryComment = mandatoryComment;
	}

	public void setCustomerComment(final String customerCommment) {
		this.customerComment = customerCommment;

	}
	public void setRefereeComment(final String refereeComment) {
		this.refereeComment = refereeComment;
	}
	public void setHandyWorkerComment(final String handyWorkerComment) {
		this.handyWorkerComment = handyWorkerComment;
	}

	public void setReport(final Report report) {
		this.report = report;
	}

}
