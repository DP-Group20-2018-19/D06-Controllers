
package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class FixUpTask extends DomainEntity {

	//Attributes

	private String					ticker;
	private Date					publishDate;
	private String					description;
	private String					address;
	private Double					maxPrice;
	private Date					periodStartDate;
	private Date					periodEndDate;

	//Relationships

	private Customer				customer;
	private Warranty				warranty;
	private Category				category;
	private Collection<Complaint>	complaints;
	private Collection<Application>	applications;


	//Getter

	@Column(unique = true)
	@NotBlank
	@Pattern(regexp = "\\d{2}\\d{2}\\d{2}-\\w{6}")
	public String getTicker() {
		return this.ticker;
	}

	@Past
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy HH:mm")
	public Date getPublishDate() {
		return this.publishDate;
	}

	@NotBlank
	public String getDescription() {
		return this.description;
	}

	@NotBlank
	public String getAddress() {
		return this.address;
	}

	@Min(value = 0)
	@Digits(fraction = 2, integer = 4)
	public Double getMaxPrice() {
		return this.maxPrice;
	}

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy HH:mm")
	public Date getPeriodStartDate() {
		return this.periodStartDate;
	}

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy HH:mm")
	public Date getPeriodEndDate() {
		return this.periodEndDate;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Customer getCustomer() {
		return this.customer;
	}

	@Valid
	@NotNull
	@OneToMany(mappedBy = "fixUpTask")
	public Collection<Complaint> getComplaints() {
		return this.complaints;
	}

	@Valid
	@NotNull
	@OneToMany(mappedBy = "fixUpTask")
	public Collection<Application> getApplications() {
		return this.applications;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Warranty getWarranty() {
		return this.warranty;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Category getCategory() {
		return this.category;
	}

	//Setter
	public void setTicker(final String ticker) {
		this.ticker = ticker;
	}

	public void setPublishDate(final Date publishDate) {
		this.publishDate = publishDate;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public void setAddress(final String address) {
		this.address = address;
	}

	public void setMaxPrice(final Double maxPrice) {
		this.maxPrice = maxPrice;
	}

	public void setPeriodStartDate(final Date periodStartDate) {
		this.periodStartDate = periodStartDate;
	}

	public void setPeriodEndDate(final Date periodEndDate) {
		this.periodEndDate = periodEndDate;
	}

	public void setCustomer(final Customer customer) {
		this.customer = customer;
	}

	public void setComplaints(final Collection<Complaint> complaints) {
		this.complaints = complaints;
	}
	public void setApplications(final Collection<Application> applications) {
		this.applications = applications;
	}

	public void setWarranty(final Warranty warranty) {
		this.warranty = warranty;
	}

	public void setCategory(final Category category) {
		this.category = category;
	}
}
