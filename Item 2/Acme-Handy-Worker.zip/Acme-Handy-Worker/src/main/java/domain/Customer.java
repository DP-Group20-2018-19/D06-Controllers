
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

@Entity
@Access(AccessType.PROPERTY)
public class Customer extends Actor {

	//Attributes
	private Double					score;

	//Relationships
	private Collection<FixUpTask>	fixUpTasks;
	private Collection<Complaint>	complaints;
	private Collection<Endorsement>	endorsements;


	//Getter

	@Range(min = -1, max = 1)
	public Double getScore() {
		return this.score;
	}

	@Valid
	@NotNull
	@OneToMany(mappedBy = "customer")
	public Collection<FixUpTask> getFixUpTasks() {
		return this.fixUpTasks;
	}

	@Valid
	@NotNull
	@OneToMany(mappedBy = "customer")
	public Collection<Complaint> getComplaints() {
		return this.complaints;
	}

	@Valid
	@NotNull
	@OneToMany(mappedBy = "customer")
	public Collection<Endorsement> getEndorsements() {
		return this.endorsements;
	}

	//Setter

	public void setScore(final Double score) {
		this.score = score;
	}

	public void setFixUpTasks(final Collection<FixUpTask> fixUpTasks) {
		this.fixUpTasks = fixUpTasks;
	}

	public void setComplaints(final Collection<Complaint> complaints) {
		this.complaints = complaints;
	}

	public void setEndorsements(final Collection<Endorsement> endorsements) {
		this.endorsements = endorsements;
	}

}
