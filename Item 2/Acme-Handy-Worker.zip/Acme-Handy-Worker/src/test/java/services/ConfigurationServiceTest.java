
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Configuration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class ConfigurationServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private ConfigurationService	configurationService;


	//Tests

	@Test
	public void testSaveConfiguration() {
		//Setting up the authority to execute services.
		this.authenticate("admin");

		//NO EXISTE CREATE NI DELETE PARA CONFIGURATION
		//Using create() to initialise a new entity. Necessary Id's taken from populated database.
		//final Configuration configuration = this.configurationService.create();
		final Configuration config = this.configurationService.findAll().iterator().next();
		//Saving entity to database and confirming it exists with findAll().
		config.getCreditCardList().add("MIABUELO");
		final Configuration saved = this.configurationService.save(config); //a�adido para que coja siempre la configuration ya que solo podemos tener una

		final Collection<Configuration> configurations = this.configurationService.findAll();
		Assert.isTrue(configurations.contains(saved));
	}

}
