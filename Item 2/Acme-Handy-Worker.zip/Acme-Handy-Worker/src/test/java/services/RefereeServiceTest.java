
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Referee;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class RefereeServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private RefereeService	refereeService;


	//Tests

	@Test
	public void testCreateReferee() {

		//Setting up the authority to execute services.

		//Using create() to initialise a new entity. Necessary Id's taken from populated database.

		final Referee referee = this.refereeService.create();

		referee.setName("Juan");
		referee.setSurname("Surjuanito");
		referee.setEmail("juansur@alum.us.es");
		referee.setPhone("654888444");
		referee.setAddress("C/ Qwerty 312");
		referee.getUserAccount().setUsername("SURSUR");
		referee.getUserAccount().setPassword("3254636");

		final Referee saved = this.refereeService.save(referee);
		final Referee bbdd = this.refereeService.findOne(saved.getId());
		Assert.notNull(bbdd);
	}
}
